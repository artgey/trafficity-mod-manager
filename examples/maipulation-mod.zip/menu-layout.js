export function categorizeMenu(panel) {
    panel.classList.add('manipulation-organized');
    const sections=[...panel.children].filter(node=>node.tagName==='SECTION');
    const firstMain=[...panel.children].find(node=>node.tagName==='H3');
    const original=[...panel.children];
    const simulation=[],cheats=[];let group=null;
    for(const child of original) {
        if(child===firstMain)group=simulation;
        else if(group===simulation&&child.tagName==='H3')group=cheats;
        if(sections.includes(child)||child.matches?.('[data-status]'))group=null;
        if(group)group.push(child);
    }
    function wrap(anchor,nodes,title,description,topic,open) {
        if(!anchor)return;
        const details=document.createElement('details');details.className='manipulation-topic';details.dataset.topic=topic;details.open=open;
        const summary=document.createElement('summary');
        const heading=document.createElement('strong');heading.textContent=title;
        const caption=document.createElement('small');caption.textContent=description;
        summary.append(heading,caption);details.appendChild(summary);
        const body=document.createElement('div');body.className='manipulation-topic-body';details.appendChild(body);
        panel.insertBefore(details,anchor);
        for(const node of nodes)body.appendChild(node);
        return body;
    }
    const sim=wrap(simulation[0],simulation,'Simulation','Pause and simulation speed','simulation',true);
    sim?.querySelector('h3')?.remove();
    wrap(cheats[0],cheats,'Cheats & progression','Money, building allowances, map tiles and levels','cheats',false);
    const labels=[['Road noise','Quiet asphalt and noise reduction','noise',false],['Traffic & traffic lights','Lane use, synchronization and signal phases','traffic',false],['Lane tools','Closures, stop signs and direction rules','road-tools',true]];
    sections.forEach((section,i)=>{
        const info=labels[i]||['More settings','','other',false];
        const body=wrap(section,[section],...info);section.querySelector('h3')?.remove();
        if(body)section.classList.add('manipulation-topic-content');
    });
    const header=panel.querySelector('header strong');if(header)header.textContent='Trafficity · Mod menu';
}
