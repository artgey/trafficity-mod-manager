import { installServiceAccessSource } from './service-access.js';
// Road rules use the game's own world-distance units. Each record belongs to
// exactly one lane; parallel lanes never inherit its signs.
export function laneMetrics(lane) {
    const cache=globalThis.__roadDistanceCache ??= new WeakMap();
    if(cache.has(lane.points)) return cache.get(lane.points);
    const distance=new Float64Array(lane.points.length);
    for(let i=1;i<distance.length;i++) {
        const a=lane.points.pointOrUndefined(i-1),b=lane.points.pointOrUndefined(i);
        distance[i]=distance[i-1]+Math.hypot(b.x-a.x,b.y-a.y);
    }
    cache.set(lane.points,distance);return distance;
}

export function pointAt(lane,index) {
    const lo=Math.max(0,Math.min(lane.points.length-1,Math.floor(index)));
    const a=lane.points.pointOrUndefined(lo),b=lane.points.pointOrUndefined(Math.min(lo+1,lane.points.length-1));
    const fraction=index-lo;
    return {x:a.x+(b.x-a.x)*fraction,y:a.y+(b.y-a.y)*fraction,a:a.a,elevation:a.elevation};
}

export function distanceIndex(metrics,distance) {
    let lo=0,hi=metrics.length-1;
    while(lo<hi) { const mid=Math.ceil((lo+hi)/2);if(metrics[mid]<=distance)lo=mid;else hi=mid-1; }
    return lo>=metrics.length-1?lo:lo+(distance-metrics[lo])/Math.max(.001,metrics[lo+1]-metrics[lo]);
}

export function junctionBoundary(network,lane,start) {
    let boundary={index:lane.points.length-1,kind:lane.intersectionIdAtEnd!=null?'intersection':lane.junctionIdAtEnd!=null?'junction':'end',id:lane.intersectionIdAtEnd??lane.junctionIdAtEnd};
    // Native routing gathers junctions from both carriageways. A sign on
    // the opposite approach must see the same T-junction boundary.
    const junctionIds=new Set(),pending=[lane.id],seenLanes=new Set();
    while(pending.length&&seenLanes.size<128){
        const id=pending.shift();if(seenLanes.has(id))continue;seenLanes.add(id);
        const peer=network.laneSections[id];if(!peer)continue;
        for(const junction of [...(peer.junctionIdsOnLeft||[]),...(peer.junctionIdsOnRight||[])])junctionIds.add(junction);
        for(const neighbor of [peer.leftGluedLaneSectionId,peer.rightGluedLaneSectionId,peer.oppositeDirectionGluedLaneSectionId])if(neighbor!=null)pending.push(neighbor);
    }
    for(const id of junctionIds) {
        const junction=network.junctions?.[id];if(!junction)continue;
        for(const locator of [junction.leftTargetLanePoint,junction.rightTargetLanePoint,...(junction.laneEnds||[]).filter(p=>p.laneSectionId===lane.id)]) {
            const target=network.laneSections[locator?.laneSectionId]?.points.pointOrUndefined(locator.pointIndex);if(!target)continue;
            let best=Infinity,index=-1;
            for(let i=0;i<lane.points.length;i+=5) {const p=lane.points.pointOrUndefined(i),d=(p.x-target.x)**2+(p.y-target.y)**2;if(d<best){best=d;index=i;}}
            const center=index;for(let i=Math.max(0,center-5);i<Math.min(lane.points.length,center+6);i++){const p=lane.points.pointOrUndefined(i),d=(p.x-target.x)**2+(p.y-target.y)**2;if(d<best){best=d;index=i;}}
            // A junction target can lie on the opposite carriageway. Its
            // longitudinal position still ends this approach's restriction.
            if(best<160**2 && index>=start-.01 && index<boundary.index) boundary={index,kind:'junction',id};
        }
    }
    return boundary;
}

export function roadExtent(network,sign,signs=[]) {
    const result={segments:[],distance:0,ending:null};
    let laneId=sign.laneId,index=sign.pointIndex,remaining=Math.max(1,Math.min(10000,Number(sign.maxDistance)||300));
    const seen=new Set();
    for(let step=0;step<128&&!seen.has(laneId);step++) {
        seen.add(laneId);const lane=network.laneSections[laneId];if(!lane?.points?.length)break;
        const metrics=laneMetrics(lane),from=metrics[Math.min(Math.max(0,index),metrics.length-1)];
        let boundary=junctionBoundary(network,lane,index);
        for(const other of signs) if(other.id!==sign.id&&['left','right','straight'].includes(other.type)&&other.laneId===laneId&&other.pointIndex>index&&other.pointIndex<boundary.index) boundary={index:other.pointIndex,kind:'sign',id:other.id};
        const available=Math.max(0,metrics[boundary.index]-from),length=Math.min(remaining,available);
        const end=distanceIndex(metrics,from+length);
        result.segments.push({laneId,from:index,to:end,length});result.distance+=length;remaining-=length;
        if(length+.001<available) {result.ending={kind:'range',laneId,index:end};break;}
        if(boundary.kind!=='end'||lane.continuesTo==null) {result.ending={...boundary,laneId};break;}
        if(remaining<=.001){result.ending={kind:'range',laneId,index:end};break;}
        const next=network.laneSections[lane.continuesTo]?.points.pointOrUndefined(0),last=pointAt(lane,end);
        if(next){
            const gap=Math.hypot(next.x-last.x,next.y-last.y),used=Math.min(gap,remaining);
            if(gap>.001){result.segments.at(-1).connectorEnd={x:last.x+(next.x-last.x)*used/gap,y:last.y+(next.y-last.y)*used/gap};result.segments.at(-1).length+=used;result.distance+=used;remaining-=used;}
            if(remaining<=.001){result.ending={kind:'range',laneId,index:end};break;}
        }
        laneId=lane.continuesTo;index=0;
    }
    return result;
}

export function roadToolsEnabled() {
    if(!(globalThis.__roadPlanningRules??globalThis.__roadRules)?.enabled)return false;
    const control=globalThis.__manipulationControl;
    return !control||control.length<4||Atomics.load(control,3)===1;
}

export function compiledRoadRules(network) {
    const source=globalThis.__roadPlanningRules??globalThis.__roadRules;
    const cache=globalThis.__compiledRoadRules;
    if(cache?.source===source&&cache.lanes===network.laneSections&&cache.junctions===network.junctions)return cache;
    const compiled={source,lanes:network.laneSections,junctions:network.junctions,points:new Map(),directions:new Map(),merges:new Map()};
    for(const sign of source?.signs||[]) {
        if(!network.laneSections[sign.laneId]?.points.pointOrUndefined(sign.pointIndex))continue;
        if(sign.type.startsWith('merge-')||sign.type.startsWith('prefer-')){if(!compiled.merges.has(sign.laneId))compiled.merges.set(sign.laneId,[]);compiled.merges.get(sign.laneId).push(sign);}
        if(['closure','stop','service'].includes(sign.type)||sign.type.startsWith('merge-')) {
            if(!compiled.points.has(sign.laneId))compiled.points.set(sign.laneId,[]);
            compiled.points.get(sign.laneId).push(sign);
        } else if(['left','right','straight'].includes(sign.type)) {
            const extent=roadExtent(network,sign,source.signs);
            for(const segment of extent.segments) {
                if(!compiled.directions.has(segment.laneId))compiled.directions.set(segment.laneId,[]);
                compiled.directions.get(segment.laneId).push({...segment,sign,ending:extent.ending});
            }
        }
    }
    globalThis.__compiledRoadRules=compiled;return compiled;
}

export function turnDirection(network,follow,arrive,connection) {
    if(connection.turnDirection)return connection.turnDirection;
    const native=nativeJunctionTurn(network,follow,arrive,connection);if(native)return native;
    const source=network.laneSections[follow.laneSectionId]?.points.pointOrUndefined(follow.pointIndex);
    const target=network.laneSections[arrive.laneSectionId]?.points.pointOrUndefined(arrive.pointIndex);
    if(!source||!target)return 'straight';
    const angle=Math.atan2(Math.sin(target.a-source.a),Math.cos(target.a-source.a));
    return Math.abs(angle)>Math.PI*.83?'uturn':Math.abs(angle)<Math.PI/4?'straight':angle>0?'right':'left';
}

export function roadTravelAllowed(network,start,follow,arrive,connection) {
    const rules=compiledRoadRules(network),pending=[{id:start.laneSectionId,index:start.pointIndex}],best=new Map();
    const turning=['use intersection','enter junction','crossing','emerge'].includes(connection.type);
    const direction=turning?turnDirection(network,follow,arrive,connection):null;
    for(let visit=0;pending.length&&visit<256;visit++) {
        const current=pending.shift(),lane=network.laneSections[current.id];if(!lane?.points?.length)continue;
        const barriers=(rules.points.get(current.id)||[]).filter(s=>s.type!=='stop'&&s.pointIndex<current.index).length;
        const passedLocks=(rules.directions.get(current.id)||[]).filter(s=>s.sign.type==='straight'&&s.to<current.index).length;
        const region=current.id+':'+barriers+':'+passedLocks;
        if(best.has(region)&&best.get(region)<=current.index)continue;best.set(region,current.index);
        let limit=lane.points.length-1;
        for(const sign of rules.points.get(current.id)||[])if((sign.type==='closure'||sign.type==='service'&&!globalThis.__serviceAccessAllowed(sign,network,globalThis.__roadPlanningAccess,globalThis.__roadPlanningDestination))&&!roadSignCompleted(sign)&&sign.pointIndex>=current.index-.01)limit=Math.min(limit,sign.pointIndex-.01);
        for(const segment of rules.directions.get(current.id)||[]) {
            if(segment.ending?.laneId!==current.id||!['intersection','junction'].includes(segment.ending.kind)||segment.to<current.index-.01)continue;
            const atEnd=follow.laneSectionId===current.id&&Math.abs(follow.pointIndex-segment.to)<1.1;
            const crossingSame=atEnd&&turning&&(roadCrossableId(network,roadConnectionId(connection))===roadCrossableId(network,segment.ending.id));
            // A route passing a side junction without entering it goes straight.
            const actual=crossingSame?direction:'straight';
            if(actual!==segment.sign.type)limit=Math.min(limit,segment.to-.01);
        }
        const merge=(rules.merges.get(current.id)||[]).filter(s=>s.type.startsWith('merge-')&&!roadSignCompleted(s)&&s.pointIndex>=current.index-15).sort((a,b)=>a.pointIndex-b.pointIndex)[0];
        const straightLimit=merge?Math.min(limit,merge.pointIndex-.01):limit;
        const lateralLimit=merge?Math.min(limit,merge.pointIndex+15):limit;
        if(current.id===follow.laneSectionId&&follow.pointIndex>=current.index-.01&&follow.pointIndex<=straightLimit+.001)return true;
        const switchAt=current.index+15;
        for(const [side,id]of [['left',lane.leftGluedLaneSectionId],['right',lane.rightGluedLaneSectionId]])if(id!=null){
            const mandatory=merge?[merge]:[];
            if(mandatory.length&&mandatory[0].type!=='merge-'+side)continue;
            const candidates=new Set([switchAt]);
            for(const barrier of rules.points.get(id)||[])if(barrier.type!=='stop')candidates.add(Math.max(switchAt,barrier.pointIndex+(barrier.type.startsWith('merge-')?16:1)));
            for(const segment of [...(rules.directions.get(current.id)||[]),...(rules.directions.get(id)||[])])if(segment.sign.type==='straight')candidates.add(Math.max(switchAt,Math.ceil(segment.to)+16));
            for(const finish of candidates){
                if(finish>lateralLimit||finish>=network.laneSections[id].points.length)continue;
                if(roadLaneChangeAllowed(network,{laneSectionId:current.id,pointIndex:finish-15},{laneSectionId:id,pointIndex:finish}))pending.push({id,index:finish});
            }
        }
        if(straightLimit>=lane.points.length-1&&lane.continuesTo!=null)pending.push({id:lane.continuesTo,index:0});
    }
    return false;
}

export function roadTransitionAllowed(network,previous,follow,arrive,connection) {
    if(!roadToolsEnabled())return true;
    return (previous.lanePointLocators||[]).some(start=>roadTravelAllowed(network,start,follow,arrive,connection));
}

export function roadMoveLimit(car,network,cars,time) {
    if(!roadToolsEnabled()||!car?.path?.length)return Infinity;
    const rules=compiledRoadRules(network),resident=car.residentId;
    const head=car.path.get(0);
    roadMergeUpdate(car,network.laneSections,head.equivalentLanePointLaneSectionId,head.equivalentLanePointPointIndex);
    if(head.isParkingPath||head.parkingArcPointsRemaining!=null||head.parkingReversePointsRemaining!=null||head.equivalentLanePointLaneSectionId==null&&(head.crossableId??head.intersectionId)!=null){car.__roadCompletedMerges={};car.__roadMergeAttempt=null;}
    const x=cars.getCarX(resident),y=cars.getCarY(resident);
    let px=x,py=y,distance=0,limit=roadCrossingLimit(car,network,cars),needsReplan=Number.isFinite(limit)||roadConflictAhead(car,network);
    const visitedStops=new Set();
    for(let i=0;i<car.path.length&&distance<1500;i++) {
        const p=car.path.get(i),laneId=p.equivalentLanePointLaneSectionId,index=p.equivalentLanePointPointIndex;
        const lane=network.laneSections[laneId];
        if(lane&&index!=null) {
            for(const sign of rules.points.get(laneId)||[]) {
                if(roadSignCompleted(sign,car))continue;
                if(sign.type==='service'&&globalThis.__serviceAccessAllowed(sign,network,globalThis.__roadAccessContext(car)))continue;
                // Check the segment from the car's real position to this path
                // point as well, so a long simulation tick cannot skip a sign.
                const at=lane.points.pointOrUndefined(sign.pointIndex);if(!at)continue;
                const forward=(at.x-x)*Math.cos(at.a)+(at.y-y)*Math.sin(at.a);
                if(sign.pointIndex>index+1||forward<-.05&&i===0)continue;
                const side=Math.abs((at.x-px)*-Math.sin(at.a)+(at.y-py)*Math.cos(at.a));
                const along=(at.x-px)*Math.cos(at.a)+(at.y-py)*Math.sin(at.a);
                const step=Math.hypot(p.x-px,p.y-py);
                if(along<-.05||along>step+3||side>12)continue;
                const to=Math.max(0,distance+along-.02);
                if(sign.type==='closure'||sign.type==='service'||sign.type.startsWith('merge-')){limit=Math.min(limit,to);needsReplan=true;}
                else {
                    visitedStops.add(sign.id);
                    const states=car.__roadStops??={};let stop=states[sign.id];
                    if(to<=.08&&!stop)stop=states[sign.id]={since:time,released:false};
                    if(stop&&time-stop.since>=2)stop.released=true;
                    if(!stop?.released)limit=Math.min(limit,to);
                }
            }

        }
        distance+=Math.hypot(p.x-px,p.y-py);px=p.x;py=p.y;
    }
    for(const id of Object.keys(car.__roadStops||{}))if(!visitedStops.has(id))delete car.__roadStops[id];
    car.__roadBlocked=Number.isFinite(limit)&&limit<1;
    car.__roadNeedsReplan=needsReplan;
    return limit;
}

export function roadLaneHorizon(car,lanes,laneId,pointIndex,offset) {
    if(!roadToolsEnabled())return Infinity;
    for(let i=0;i<Math.abs(offset);i++)laneId=offset<0?lanes[laneId]?.leftGluedLaneSectionId:lanes[laneId]?.rightGluedLaneSectionId;
    let distance=0;
    for(let step=0;step<64;step++) {
        const lane=lanes[laneId];if(!lane)return Infinity;
        let closest=Infinity;
        for(const sign of globalThis.__roadRules.signs||[])if((sign.type==='closure'||sign.type.startsWith('merge-'))&&!roadSignCompleted(sign,car)&&sign.laneId===laneId&&sign.pointIndex>=pointIndex)closest=Math.min(closest,sign.pointIndex-pointIndex);
        if(Number.isFinite(closest))return distance+closest;
        distance+=lane.points.length-pointIndex;
        if(lane.continuesTo==null)return Infinity;laneId=lane.continuesTo;pointIndex=0;
    }
    return Infinity;
}

export function roadBrakeSpeed(car,network,cars,time) {
    const distance=roadMoveLimit(car,network,cars,time);
    // Anticipate the sign; the movement limit independently prevents overshoot.
    return Number.isFinite(distance)?Math.sqrt(2*45*distance):Infinity;
}


export function roadConflictAhead(car,network) {
    const head=car.path.get(0),id=head.equivalentLanePointLaneSectionId,index=head.equivalentLanePointPointIndex;
    if(id!=null&&Number.isFinite(roadLaneHorizon(car,network.laneSections,id,index,0)))return true;
    const serviceSigns=(globalThis.__roadRules?.signs||[]).filter(sign=>sign.type==='service');
    const access=serviceSigns.length?globalThis.__roadAccessContext(car):null;
    const denied=serviceSigns.filter(sign=>!globalThis.__serviceAccessAllowed(sign,network,access));
    if(denied.length&&globalThis.__roadRouteAffected(car,network,denied))return true;
    const next=(car.route||[]).find(node=>node.edgeToGetHere&&['use intersection','crossing','enter junction','emerge'].includes(node.connectionIntoThisNode?.type));
    if(!next)return false;
    const c=next.connectionIntoThisNode,source=c.sourceLaneId??c.sourceLaneSectionId??next.edgeToGetHere.destinationLanePointLocator?.laneSectionId,target=c.targetLaneId??c.targetLaneSectionId??next.lanePointLocators?.[0]?.laneSectionId;
    return roadMovementForbidden(network,source,target,roadConnectionId(c),c,next.edgeToGetHere.destinationLanePointLocator,next.lanePointLocators?.[0]);
}

export function roadDesiredOffset(car,lanes,laneId,index,getDistance,original) {
    if(!roadToolsEnabled())return original;
    roadMergeUpdate(car,lanes,laneId,index);
    const sign=(globalThis.__roadRules.signs||[]).filter(s=>!roadSignCompleted(s,car)&&s.laneId===laneId&&(s.type.startsWith('merge-')||s.type.startsWith('prefer-'))&&s.pointIndex>=index-1&&s.pointIndex-index<=20).sort((a,b)=>a.pointIndex-b.pointIndex)[0];
    if(!sign)return original;
    const offset=sign.type.endsWith('left')?-1:1,neighbor=offset<0?lanes[laneId]?.leftGluedLaneSectionId:lanes[laneId]?.rightGluedLaneSectionId;
    const available=neighbor!=null?getDistance(offset):null;
    const preferred=sign.type.startsWith('prefer-');
    if(preferred&&(available==null||available<25||globalThis.__trafficPreferAllowed&&!globalThis.__trafficPreferAllowed(car,lanes,laneId,index,offset)))return original;
    const routeAllows=neighbor!=null&&car.allowedLaneSubsections?.some(s=>s.laneSectionId===neighbor&&s.firstAllowedPointIndex<=index+12&&s.lastAllowedPointIndex>=index+12);
    if(available!=null&&available>=12||!preferred&&routeAllows){car.__roadMergeAttempt={id:sign.id,key:roadSignKey(sign),target:neighbor};return offset;}
    return sign.type.startsWith('merge-')?0:original;
}

export function roadSignKey(sign) { return [sign.type,sign.laneId,sign.pointIndex].join(':'); }
export function roadSignCompleted(sign,car) { return (car?.__roadCompletedMerges||globalThis.__roadPlanningCompleted||{})[sign.id]===roadSignKey(sign); }

export function roadMergeUpdate(car,lanes,laneId,index) {
    const attempt=car.__roadMergeAttempt;
    if(!attempt)return;
    let id=attempt.target;
    for(let step=0;id!=null&&step<64;step++,id=lanes[id]?.continuesTo) {
        if(id===laneId&&car.path?.get(0)?.switchingLaneFromLaneSectionId==null) {
            (car.__roadCompletedMerges??={})[attempt.id]=attempt.key;
            car.__roadMergeAttempt=null;return;
        }
    }
}

export function roadResolveMovement(car,network,id,pathPoint) {
    const sourceHint=pathPoint?.comingFromId??pathPoint?.enteringJunctionLaneSectionId??pathPoint?.emergingFromIntersectionLaneSectionId;
    const targetHint=pathPoint?.headingToId;
    const nodes=[...(car.route||[]),...(car.shiftedRouteNodes||[]).slice().reverse()];
    const node=nodes.find(n=>{
        const c=n.connectionIntoThisNode;if(!c)return false;
        const match=roadCrossableId(network,roadConnectionId(c))===roadCrossableId(network,id);
        const source=c.sourceLaneId??c.sourceLaneSectionId??n.edgeToGetHere?.destinationLanePointLocator?.laneSectionId;
        const target=c.targetLaneId??c.targetLaneSectionId??n.lanePointLocators?.[0]?.laneSectionId;
        return match&&(sourceHint==null||source===sourceHint)&&(targetHint==null||target===targetHint);
    });
    const connection=node?.connectionIntoThisNode||{};
    const follow=node?.edgeToGetHere?.destinationLanePointLocator;
    const arrive=node?.lanePointLocators?.[0];
    const source=sourceHint??connection.sourceLaneId??connection.sourceLaneSectionId??follow?.laneSectionId;
    const target=targetHint??connection.targetLaneId??connection.targetLaneSectionId??arrive?.laneSectionId;
    if(source==null||target==null)return null;
    const crossable=network.intersections?.[id]??network.junctions?.[id];
    const geometry=crossable?.crossablePathSet?.[source]?.[target];
    return {source,target,connection,follow:follow??geometry?.sourceLanePointLocator,arrive:arrive??geometry?.targetLanePointLocator};
}

export function roadEntry(network,source,id) {
    const lane=network.laneSections[source];if(!lane)return null;
    const segment=(compiledRoadRules(network).directions.get(source)||[]).find(s=>roadCrossableId(network,s.ending?.id)===roadCrossableId(network,id)&&['intersection','junction'].includes(s.ending.kind));
    return {laneSectionId:source,pointIndex:segment?Math.round(segment.to):lane.points.length-1};
}

export function roadMovementForbidden(network,sourceId,targetId,crossableId,connection={},follow,arrive) {
    if(!roadToolsEnabled()||!network.laneSections[sourceId]||!network.laneSections[targetId])return false;
    const entry=follow??roadEntry(network,sourceId,crossableId);
    const exit=arrive??{laneSectionId:targetId,pointIndex:0};
    const direction=turnDirection(network,entry,exit,connection);
    return (compiledRoadRules(network).directions.get(sourceId)||[]).some(segment=>roadCrossableId(network,segment.ending?.id)===roadCrossableId(network,crossableId)&&['intersection','junction'].includes(segment.ending.kind)&&segment.sign.type!==direction);
}

export function roadCrossingLimit(car,network,cars) {
    const x=cars.getCarX(car.residentId),y=cars.getCarY(car.residentId);let px=x,py=y,distance=0;
    for(let i=0;i<car.path.length;i++) {
        const p=car.path.get(i),id=p.intersectionId??p.crossableId;
        if(id!=null) {
            const move=roadResolveMovement(car,network,id,p);
            if(move&&roadMovementForbidden(network,move.source,move.target,id,move.connection,move.follow,move.arrive)) {
                const entry=move.follow??roadEntry(network,move.source,id);
                const end=pointAt(network.laneSections[entry.laneSectionId],entry.pointIndex),head=car.path.get(0);
                const inside=head.equivalentLanePointLaneSectionId==null&&(head.intersectionId??head.crossableId)===id;
                if(inside&&((x-end.x)*Math.cos(end.a)+(y-end.y)*Math.sin(end.a)>.05||car.hardLockTail?.hasCrossable?.(id)))return Infinity;
                return Math.max(0,distance+Math.hypot(end.x-px,end.y-py)-.02);
            }
        }
        distance+=Math.hypot(p.x-px,p.y-py);px=p.x;py=p.y;
    }
    return Infinity;
}

export function roadRuleChanges(before,after) {
    if(!before?.enabled&&!after?.enabled)return [];
    const old=new Map((before?.enabled?before.signs:[]).map(sign=>[sign.id,sign]));
    const next=new Map((after?.enabled?after.signs:[]).map(sign=>[sign.id,sign]));
    const changed=[];
    for(const id of new Set([...old.keys(),...next.keys()]))if(JSON.stringify(old.get(id))!==JSON.stringify(next.get(id))){
        for(const sign of [old.get(id),next.get(id)])if(sign&&sign.type!=='stop')changed.push(sign);
    }
    return changed;
}

export function roadRouteAffected(car,network,signs) {
    if(!car.path?.length||!car.route?.length||!signs?.length)return false;
    const head=car.path.get(0),currentId=head.equivalentLanePointLaneSectionId,currentIndex=head.equivalentLanePointPointIndex;
    for(const sign of signs){
        const directional=['left','right','straight'].includes(sign.type);
        for(let i=0;i<car.path.length;i++){
            const p=car.path.get(i);
            if(p.equivalentLanePointLaneSectionId===sign.laneId&&(directional||p.equivalentLanePointPointIndex<=sign.pointIndex))return true;
        }
        for(let i=0;i<car.route.length;i++){
            const node=car.route[i],edge=node.edgeToGetHere;
            for(const part of edge?.allowedLaneSubsections||[]){
                const from=i===0&&part.laneSectionId===currentId?Math.max(part.firstAllowedPointIndex,currentIndex):part.firstAllowedPointIndex;
                if(part.laneSectionId===sign.laneId&&sign.pointIndex<=part.lastAllowedPointIndex&&(directional||sign.pointIndex>=from))return true;
            }
            const dest=edge?.destinationLanePointLocator;
            if(dest?.laneSectionId===sign.laneId&&dest.pointIndex>=sign.pointIndex&&(i>0||currentId!==sign.laneId||directional||currentIndex<=sign.pointIndex))return true;
        }
        let laneId=currentId,index=currentIndex;
        for(let count=0;laneId!=null&&count<64;count++){
            const lane=network.laneSections[laneId];if(!lane)break;
            if(laneId===sign.laneId&&(directional||sign.pointIndex>=index))return true;
            laneId=lane.continuesTo;index=0;
        }
    }
    return false;
}

export function roadCrossableId(network,id) { return network.junctions?.[id]?.junctionGroupLeaderId??id; }

export function roadConnectionId(connection) { return connection.intersectionId??connection.junctionId??connection.leaderJunctionId??connection.emergeSource?.junctionId; }

export function nativeJunctionTurn(network,follow,arrive,connection) {
    if(connection.type!=='emerge')return null;
    const id=roadCrossableId(network,roadConnectionId(connection)),junction=network.junctions?.[id];
    if(!junction?.leftTargetLanePoint||!junction?.rightTargetLanePoint||!globalThis.parcelRequireeccb)return null;
    const helpers=globalThis.parcelRequireeccb('kBGMy');
    const left=helpers.getEmergeFromLocationLeftTurnLanePoint(network,junction.direction,junction.leftTargetLanePoint);
    const right=helpers.getEmergeFromLocationRightTurnLanePoint(network,junction.direction,junction.rightTargetLanePoint);
    const match=p=>p?.laneSectionId===arrive.laneSectionId&&p.pointIndex===arrive.pointIndex;
    if(match(left)&&!match(right))return 'left';
    if(match(right)&&!match(left))return 'right';
    return null;
}

export function roadLaneContinues(lanes,start,target) {
    const seen=new Set();
    for(let id=start;id!=null&&!seen.has(id)&&seen.size<128;id=lanes[id]?.continuesTo){if(id===target)return true;seen.add(id);}
    return false;
}

export function roadLaneSpanLocked(network,start,end) {
    const directions=compiledRoadRules(network).directions,seen=new Set();
    let id=start.laneSectionId,from=start.pointIndex;
    while(id!=null&&!seen.has(id)&&seen.size<128){
        seen.add(id);const lane=network.laneSections[id];if(!lane?.points?.length)break;
        const to=id===end.laneSectionId?end.pointIndex:lane.points.length-1;
        if((directions.get(id)||[]).some(s=>s.sign.type==='straight'&&from<=s.to+.001&&to>=s.from-.001))return true;
        if(id===end.laneSectionId)break;id=lane.continuesTo;from=0;
    }
    return false;
}

export function roadLaneHasStraight(network,start) {
    const directions=compiledRoadRules(network).directions,seen=new Set();
    for(let id=start;id!=null&&!seen.has(id)&&seen.size<128;id=network.laneSections[id]?.continuesTo){
        seen.add(id);if((directions.get(id)||[]).some(segment=>segment.sign.type==='straight'))return true;
    }
    return false;
}

export function roadLaneChangeAllowed(network,from,to) {
    if(!roadToolsEnabled()||!from||!to||from.laneSectionId===to.laneSectionId)return true;
    if(!roadLaneHasStraight(network,from.laneSectionId)&&!roadLaneHasStraight(network,to.laneSectionId))return true;
    const lanes=network.laneSections,source=lanes[from.laneSectionId],target=lanes[to.laneSectionId];
    if(!source||!target)return false;
    let targetStart,sourceEnd;
    if(roadLaneContinues(lanes,source.rightGluedLaneSectionId,to.laneSectionId)){
        targetStart=source.rightGluedLaneSectionId;sourceEnd=target.leftGluedLaneSectionId;
    }else if(roadLaneContinues(lanes,source.leftGluedLaneSectionId,to.laneSectionId)){
        targetStart=source.leftGluedLaneSectionId;sourceEnd=target.rightGluedLaneSectionId;
    }else return false;
    if(sourceEnd==null||targetStart==null)return false;
    return !roadLaneSpanLocked(network,from,{laneSectionId:sourceEnd,pointIndex:to.pointIndex})&&
        !roadLaneSpanLocked(network,{laneSectionId:targetStart,pointIndex:from.pointIndex},to);
}

export function roadLaneOffsetAllowed(car,network,offset) {
    if(!roadToolsEnabled()||!offset||!car?.path?.length)return true;
    const head=car.path.get(0);let id=head.equivalentLanePointLaneSectionId,index=head.equivalentLanePointPointIndex;
    if(id==null||index==null)return true;
    for(let step=0;step<Math.abs(offset);step++){
        const lane=network.laneSections[id],target=offset<0?lane?.leftGluedLaneSectionId:lane?.rightGluedLaneSectionId;
        if(target==null)return false;
        const end=Math.min(index+15,network.laneSections[target].points.length-1);
        if(!roadLaneChangeAllowed(network,{laneSectionId:id,pointIndex:index},{laneSectionId:target,pointIndex:end}))return false;
        id=target;
    }
    return true;
}

export function installRoadRuleSource(source) {
    const functions=[laneMetrics,pointAt,distanceIndex,junctionBoundary,roadExtent,roadToolsEnabled,compiledRoadRules,turnDirection,roadTravelAllowed,roadTransitionAllowed,roadMoveLimit,roadBrakeSpeed,roadLaneHorizon,roadMovementForbidden,roadConflictAhead,roadCrossingLimit,roadDesiredOffset,roadSignKey,roadSignCompleted,roadMergeUpdate,roadResolveMovement,roadEntry,roadRuleChanges,roadRouteAffected,roadCrossableId,roadConnectionId,nativeJunctionTurn,roadLaneContinues,roadLaneSpanLocked,roadLaneChangeAllowed,roadLaneOffsetAllowed,roadLaneHasStraight];
    return installServiceAccessSource('(function(){'+functions.map(fn=>fn.toString()).join('\n')+';Object.assign(globalThis,{__roadLaneChangeAllowed:roadLaneChangeAllowed,__roadLaneOffsetAllowed:roadLaneOffsetAllowed,__roadRuleChanges:roadRuleChanges,__roadRouteAffected:roadRouteAffected,__roadDesiredOffset:roadDesiredOffset,__roadToolsEnabled:roadToolsEnabled,__roadTransitionAllowed:roadTransitionAllowed,__roadMoveLimit:roadMoveLimit,__roadBrakeSpeed:roadBrakeSpeed,__roadLaneHorizon:roadLaneHorizon});globalThis.__roadRules={enabled:false,signs:[]};self.addEventListener("message",event=>{if(event.data?.type!=="maipulation-road-tools")return;const previous=globalThis.__roadRules;globalThis.__roadRules={enabled:event.data.enabled,signs:event.data.signs||[],revision:event.data.revision};globalThis.__roadRuleChangedSigns=roadRuleChanges(previous,globalThis.__roadRules);globalThis.__onRoadRulesChanged?.();event.stopImmediatePropagation();},true);})();\n'+source);
}
