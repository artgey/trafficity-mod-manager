import { installTrafficSafetySource } from './traffic-safety.js';
import { patchAdaptiveTraffic } from './traffic-adapt.js';
export function chooseTrafficLane(car,low,high,getDistance,getProbe,original,laneId,pointIndex,lanes,forced) {
    const stats=globalThis.__trafficStats??={checks:0,changes:0,heldAtSignal:0};stats.checks++;
    if(forced)return original;
    const lane=lanes[laneId],center=getDistance(0);
    const validCurrent=car.allowedLaneSubsections?.some(part=>part.laneSectionId===laneId&&part.firstAllowedPointIndex<=pointIndex&&part.lastAllowedPointIndex>=lane.points.length-1);
    const now=globalThis.__trafficClock?.[0]||0;
    const optional=globalThis.__trafficChangeRequired?!globalThis.__trafficChangeRequired(car,{laneSections:lanes}):false;
    const noRoadBlock=!(globalThis.__roadLaneHorizon?.(car,lanes,laneId,pointIndex,0)<=30);
    if(validCurrent&&center!=null&&noRoadBlock){
        if(now<(car.__trafficStayUntil||0))return 0;
        if(center>=60&&getProbe(0)?.encoded>=0)return 0;
    }
    const near=lane.intersectionIdAtEnd!=null&&lane.points.length-1-pointIndex<25;
    function decision(offset,held=false){if(offset!==original)stats.changes++;if(held&&offset!==original)stats.heldAtSignal++;return offset;}
    // Only hold the final short approach if this very lane reaches the planned
    // exit legally. Earlier decisions remain free to distribute real queues.
    if(near&&validCurrent&&center!=null&&center>5&&!Number.isFinite(globalThis.__roadLaneHorizon?.(car,lanes,laneId,pointIndex,0)))return decision(0,true);
    
    const candidates=[];
    for(let offset=low;offset<=high;offset++) {
        if(validCurrent&&Math.abs(offset)>1)continue;
        const free=getDistance(offset);if(free==null)continue;
        let id=laneId;for(let step=0;step<Math.abs(offset);step++)id=offset<0?lanes[id]?.leftGluedLaneSectionId:lanes[id]?.rightGluedLaneSectionId;
        if(id==null)continue;
        // A discretionary lane choice must not create braking pressure while
        // its destination is occupied. Probe without reserving or mutating
        // the car; native collision checks still run at the actual manoeuvre.
        if(optional&&offset!==0&&globalThis.__trafficCars&&globalThis.__trafficMergeGap){
            const target=lanes[id];
            if(Math.abs(offset)!==1||pointIndex+15>=target.points.length||!globalThis.__trafficMergeGap(
                {roadNetwork:{laneSections:lanes},carMetadata:globalThis.__trafficCars},car,
                {laneSectionId:laneId,pointIndex},{laneSectionId:id,pointIndex:pointIndex+15},now,false,true))continue;
        }
        const probe=getProbe(offset);
        const score=Math.min(400,free)*.055-Math.min(600,probe?.congestionLength||0)*.02-Math.abs(offset)*2;
        candidates.push({offset,score});
    }
    if(!candidates.length)return original;
    candidates.sort((a,b)=>b.score-a.score||Math.abs(a.offset)-Math.abs(b.offset));
    const current=candidates.find(candidate=>candidate.offset===0),best=candidates[0];
    if(current&&best.score-current.score<4)return decision(0);
    return decision(best.offset);
}

export function patchTrafficWorker(source, enabled) {
    const needle = 'K=g(V,q,l,o)';
    if (source.split(needle).length !== 2) throw new Error('Traffic use: unsupported worker version.');
    const prefix = `globalThis.__intelligentTraffic=${Boolean(enabled)};globalThis.__chooseTrafficLane=${chooseTrafficLane.toString()};self.addEventListener('message',function(event){if(event.data?.type==='maipulation-traffic-use'){globalThis.__intelligentTraffic=event.data.enabled;event.stopImmediatePropagation();}},true);\n`;
    let patched = source.replace(needle, 'K=globalThis.__roadDesiredOffset?.(e,t,v,L,U,((globalThis.__manipulationControl?Atomics.load(globalThis.__manipulationControl,1)===1:globalThis.__intelligentTraffic)?globalThis.__chooseTrafficLane(e,V,q,U,D,g(V,q,l,o),v,L,t,null!==F):g(V,q,l,o)))??g(V,q,l,o)');
    const bid = '(0,o.canSourceLaneProceedThroughIntersection)(i,t,this.intersectionMetadata)||this.carHasCommittedToIntersectionCrossing(n,e.id)';
    if (patched.split(bid).length !== 2) throw new Error('Phase routing: unsupported worker version.');
    patched = patched.replace(bid, '((0,o.canSourceLaneProceedThroughIntersection)(i,t,this.intersectionMetadata)&&globalThis.__phaseMovementAllowed(i,t,this.partitionCars[n],this.intersectionMetadata))||this.carHasCommittedToIntersectionCrossing(n,e.id)');
    const obtain = 'tryObtainCrossableLocks(e,t){';
    if (patched.split(obtain).length !== 2) throw new Error('Phase routing: unsupported intersection lock version.');
    patched = patched.replace(obtain, obtain + 'const signal=this.roadNetwork.intersections[e.id];if(signal&&!this.carHasCommittedToIntersectionCrossing(t.residentId,e.id)){for(const entry of t.crossableLockSet.entries){if(entry.crossableId===e.id&&entry.state===a.CrossableLockState.BIDDED&&!globalThis.__phaseMovementAllowed(signal,entry.comingFromId,t,this.intersectionMetadata))return{obtained:false,lostAuction:false};}}');
    const probeNeedle='let n=p(t.encoded);return null!==G?Math.min(n,G):n';
    if(patched.split(probeNeedle).length!==2)throw new Error('Lane tools: unsupported lane probe version.');
    patched=patched.replace(probeNeedle,'let n=Math.min(p(t.encoded),globalThis.__roadLaneHorizon?.(e,t,v,L,e)??Infinity);return null!==G?Math.min(n,G):n');
    // U's argument e is the lane offset; t above is its probe, so explicitly
    // capture the parent car and lane dictionary through a short closure.
    patched=patched.replace('U=e=>{if(0===e&&H)', 'U=((car,lanes)=>(e=>{if(0===e&&H)');
    patched=patched.replace('globalThis.__roadLaneHorizon?.(e,t,v,L,e)', 'globalThis.__roadLaneHorizon?.(car,lanes,v,L,e)');
    patched=patched.replace('return null!==G?Math.min(n,G):n},W=0', 'return null!==G?Math.min(n,G):n}))(e,t),W=0');
    const destination='c=null!=$&&$>=0&&$<150?0:K';
    if(patched.split(destination).length!==2)throw new Error('Lane tools: unsupported destination approach version.');
    patched=patched.replace(destination,()=> 'c=null!=$&&$>=0&&$<150&&!Number.isFinite(globalThis.__roadLaneHorizon?.(e,t,v,L,0))?0:K');
    const shortMerge='null!==n&&null!==i&&i<n&&i<100&&(c=0)';
    if(patched.split(shortMerge).length!==2)throw new Error('Lane tools: unsupported short lane-change probe.');
    patched=patched.replace(shortMerge,'null!==n&&null!==i&&i<n&&i<100&&!Number.isFinite(globalThis.__roadLaneHorizon?.(e,t,v,L,0))&&(c=0)');
    const safetyHooks=[
        ['trySwitchTowardTargetLane(e,t){let n,i=this.partitionCars[e];','trySwitchTowardTargetLane(e,t){try{let n,i=this.partitionCars[e];if(i.cleanswitchLockId!=null||i.path?.get(0)?.switchingLaneFromLaneSectionId!=null)return false;'],
        ['return j.release(),!!z.path}resetLaneSwitchStateForNewRouteHead(e){','return j.release(),!!z.path}finally{globalThis.__trafficMergeFinish(this.partitionCars[e]);}}resetLaneSwitchStateForNewRouteHead(e){globalThis.__releaseTrafficMerge(e);'],
        ['outcome:"pending"};if(!F){','outcome:"pending"};if(F&&H&&!globalThis.__trafficMergeGap(this,i,{laneSectionId:r,pointIndex:a},H,this.gameTime))return false;if(!F&&globalThis.__trafficBlockedOptional(this,i,this.gameTime))return false;if(!F){'],
        ['let Y=s.lastAllowedPointIndex??a;for(i.framesSinceLastGobble=0;','if(!globalThis.__trafficPathClear(this,i,j,this.gameTime)){j.release();return false;}let Y=s.lastAllowedPointIndex??a;for(i.framesSinceLastGobble=0;'],
        ['u.longMode={pointsAhead:p.pointsAhead,','if(!globalThis.__trafficMergeGap(this,e,r,p.landingLocator,this.gameTime))return false;u.longMode={pointsAhead:p.pointsAhead,'],
        ['for(e.framesSinceLastGobble=0;e.path.length>0;)this.gobblePathPointAndAddPollution(e);this.releaseAllCrossableLocksForCar(t),this.forceFlushGarbageCrossableLocksForCar(t),e.path.clear(),this.clearIntersectionCrossingCommitment(e),this.acquireCleanswitchLock(e,p.probeX,p.probeY,p.probeA,c);','if(!globalThis.__trafficPathClear(this,e,g,this.gameTime)){g.release();return false;}for(e.framesSinceLastGobble=0;e.path.length>0;)this.gobblePathPointAndAddPollution(e);this.releaseAllCrossableLocksForCar(t),this.forceFlushGarbageCrossableLocksForCar(t),e.path.clear(),this.clearIntersectionCrossingCommitment(e),this.acquireCleanswitchLock(e,p.probeX,p.probeY,p.probeA,c);'],
        ['this.releasePushInLock(i),i.lastLaneChangeGameTime=this.gameTime','this.releasePushInLock(i),i.__trafficMergeAccepted=true,i.__trafficStayUntil=this.gameTime+2.5,i.lastLaneChangeGameTime=this.gameTime'],
        ['this.releasePushInLock(e),e.lastLaneChangeGameTime=this.gameTime','this.releasePushInLock(e),e.__trafficMergeAccepted=true,e.__trafficStayUntil=this.gameTime+2.5,e.lastLaneChangeGameTime=this.gameTime'],
        ['let e=n.residentId,i=(0,Z.carIsWaitingForPathfinding)(n);','let e=n.residentId,i=(globalThis.__trafficSafetyTick(n,eA,e_[0]),(0,Z.carIsWaitingForPathfinding)(n));']
    ];
    for(const [needle,replacement]of safetyHooks){if(patched.split(needle).length!==2)throw new Error('Safe lane changes: unsupported game version.');patched=patched.replace(needle,replacement);}
    const restrictions=[
        ['let d=(0,R.getLaneSwitchHorizonForCarAt)(i.allowedLaneSubsections,r,a);','if(!globalThis.__roadLaneChangeAllowed(this.roadNetwork,{laneSectionId:r,pointIndex:a},{laneSectionId:n,pointIndex:a}))return false;let d=(0,R.getLaneSwitchHorizonForCarAt)(i.allowedLaneSubsections,r,a);'],
        ['outcome:"pending"};if(F&&H&&','outcome:"pending"};if(H&&!globalThis.__roadLaneChangeAllowed(this.roadNetwork,{laneSectionId:r,pointIndex:a},H))return false;if(F&&H&&'],
        ['if(this.cleanswitchLandingLeavesNoRoom(e,p.landingLocator,h))','if(!globalThis.__roadLaneChangeAllowed(this.roadNetwork,r,p.landingLocator))return false;if(this.cleanswitchLandingLeavesNoRoom(e,p.landingLocator,h))'],
        ['s=(0,en.runLaneSwitchingPeriodicCheck)(n,ec.laneSections,eF,ec.drivingSide,a);','s=(0,en.runLaneSwitchingPeriodicCheck)(n,ec.laneSections,eF,ec.drivingSide,a);if(s!==null&&s!==0&&!globalThis.__roadLaneOffsetAllowed(n,ec,s))s=0;']
    ];
    for(const [needle,replacement]of restrictions){if(patched.split(needle).length!==2)throw new Error('Straight-only lane binding: unsupported game version.');patched=patched.replace(needle,replacement);}
    const movementNeedle = 'let n=eA.getSpeed(i.residentId),r=t/1e3,o=n*r,a=0;';
    if (patched.split(movementNeedle).length !== 2) throw new Error('Phase routing: unsupported movement calculation.');
    patched = patched.replace(movementNeedle, 'let n=eA.getSpeed(i.residentId),r=t/1e3,o=Math.min(n*r,i.__trafficAnchorRetry?0:Infinity,globalThis.__phaseMoveLimit(i,ec,eN,eA),globalThis.__roadMoveLimit?.(i,ec,eA,e_[0])??Infinity,(globalThis.__roadBrakeSpeed?.(i,ec,eA,e_[0])??Infinity)*r),a=0;if(o<n*r)eA.setSpeed(i.residentId,r>0?o/r:0);');
    const routingPrefix = 'globalThis.__crossingMovement=' + crossingMovement.toString() + ';globalThis.__phaseMoveLimit=' + phaseMoveLimit.toString() + ';globalThis.__parallelSignalLanes={};globalThis.__phaseRouting={};globalThis.__phaseRoutingEnabled=false;globalThis.__phaseMovementAllowed=' + phaseMovementAllowed.toString() + ';self.addEventListener("message",function(event){if(event.data?.type==="maipulation-signal-routing"){globalThis.__parallelSignalLanes=event.data.parallel;globalThis.__phaseRouting=event.data.plans;globalThis.__phaseRoutingEnabled=event.data.enabled;event.stopImmediatePropagation();}},true);\n';
    return installTrafficSafetySource(prefix + routingPrefix + patchAdaptiveTraffic(patched));
}

export function signalAt(intersection, time, offset) {
    const phases = intersection.phaseIds.map(id => intersection.phases[id]);
    if (!phases.length || phases.some(phase => !phase || !Number.isFinite(phase.durationSeconds) || phase.durationSeconds < 3)) return null;
    const cycle = phases.reduce((sum, phase) => sum + phase.durationSeconds, 0);
    let position = ((time - offset) % cycle + cycle) % cycle;
    for (const phase of phases) {
        if (position < phase.durationSeconds) {
            const remaining = phase.durationSeconds - position;
            return { id: phase.id, remaining, amber: remaining <= 1.5 };
        }
        position -= phase.durationSeconds;
    }
    return null;
}

export function crossingMovement(car, intersectionId, requestedSource) {
    for (let index = 0; car?.path && index < car.path.length; index++) {
        const point = car.path.get(index);
        if ((point.intersectionId ?? point.crossableId) !== intersectionId) continue;
        const source = point.comingFromId ?? point.enteringJunctionLaneSectionId;
        if (source != null && point.headingToId != null && (requestedSource == null || source === requestedSource)) return { source, target: point.headingToId };
    }
    for (const node of [...(car?.route || []), ...(car?.shiftedRouteNodes || []).slice().reverse()]) {
        const connection = node.connectionIntoThisNode;
        if (connection?.type === 'use intersection' && connection.intersectionId === intersectionId && (requestedSource == null || connection.sourceLaneId === requestedSource)) return { source: connection.sourceLaneId, target: connection.targetLaneId };
    }
    return null;
}

export function phaseMovementAllowed(intersection, source, car, metadata) {
    if (!globalThis.__phaseRoutingEnabled) return true;
    const plan = globalThis.__phaseRouting?.[intersection.id];
    if (!plan?.connections) return true;
    const phaseId = metadata.getCurrentPhaseId(intersection.id);
    const phase = plan.connections[phaseId] || plan.baseConnections;
    if (!phase) return false;
    // Other workers' auction bids may refer to a car owned by another partition.
    // Admission and physical movement are checked again by its owning worker.
    if (!car) return true;
    const movement = globalThis.__crossingMovement(car, intersection.id, source);
    return movement != null && (phase[movement.source] || []).includes(movement.target);
}

export function phaseMoveLimit(car, network, metadata, cars) {
    if (!globalThis.__phaseRoutingEnabled || !car?.path?.length) return Infinity;
    const x = cars.getCarX(car.residentId), y = cars.getCarY(car.residentId);
    let previousX = x, previousY = y, distance = 0;
    for (let index = 0; index < car.path.length; index++) {
        const point = car.path.get(index);
        const id = point.intersectionId ?? point.crossableId;
        const intersection = network.intersections[id];
        if (intersection && globalThis.__phaseRouting?.[id]?.connections) {
            const movement = globalThis.__crossingMovement(car, id);
            if (!movement) return Math.max(0, distance - 0.01);
            const source = network.laneSections[movement.source];
            const end = source?.points.pointOrUndefined(source.points.length - 1);
            // Only a vehicle physically beyond the entry line may finish clearing
            // after its phase changes. Merely reserving locks is insufficient.
            const head = car.path.get(0);
            const onCrossingCurve = head.equivalentLanePointLaneSectionId == null && (head.intersectionId ?? head.crossableId) === id;
            const pastEntry = end && (x - end.x) * Math.cos(end.a) + (y - end.y) * Math.sin(end.a) > 0.05;
            if (onCrossingCurve && (pastEntry || car.hardLockTail?.hasCrossable?.(id))) return Infinity;
            if (!globalThis.__phaseMovementAllowed(intersection, movement.source, car, metadata)) {
                const toEntry = end ? distance + Math.hypot(end.x - previousX, end.y - previousY) : distance;
                const stats = globalThis.__trafficStats ??= { checks:0, changes:0, heldAtSignal:0 };
                stats.blockedDirections = (stats.blockedDirections || 0) + 1;
                return Math.max(0, toEntry - 0.01);
            }
        }
        distance += Math.hypot(point.x - previousX, point.y - previousY);
        previousX = point.x; previousY = point.y;
    }
    return Infinity;
}
