import { installNativeSignals } from './native-signals.js';
import { connectionsOf, withConnections, parallelLanes, phaseConnectionEditor } from './phase-connections.js';
import { signalAt } from './traffic-core.js';

export function installTraffic(modApi, game, config, panel, trafficHook) {
    let intelligent = config.intelligentTraffic === true;
    let modern = config.modernTrafficLights === true;
    const section = document.createElement('section');
    section.innerHTML = `<h3>Traffic &amp; traffic lights</h3>
      <label class="traffic-toggle"><input type="checkbox" data-intelligent> Activate intelligent Traffic use</label>
      <label class="traffic-toggle"><input type="checkbox" data-modern> Activate Modern Traffic light system</label>
      <p class="hint">Intelligent traffic use balances legal routes across available lanes. Lane changes consider safe front and rear gaps and shared merge reservations. Vehicles avoid unnecessary weaving while queues can still use free adjacent lanes. General and per-phase connections, right-of-way and intersection locks remain in force.</p>
      <div data-signal-tools>
        <button data-action="refresh">Refresh traffic light list</button><button data-action="pick">Select traffic light opened on map</button>
        <div data-signals class="traffic-list"></div>
        <button data-action="sync">Synchronize selected traffic lights</button><button data-action="unsync">Unlink synchronization</button>
        <p class="hint">Synchronization requires the same number of phases and matching durations in the same order. Green lanes may differ between junctions. Phase durations include 1.5 seconds of amber.</p>
        <h3>Individual signal phases</h3><p data-selected-signal></p><button data-action="restore">Restore general connections</button><select data-edit aria-label="Edit traffic light"></select>
        <label>Time offset in seconds <input data-offset type="number" min="0" max="3600" value="0"></label>
        <p data-live-signal class="hint"></p><div data-phases></div><button data-action="add">Add phase</button>
        <p class="hint">Each phase can have custom connections. Unedited phases inherit the general connections. Restore resets all custom connections to the general diagram. Phase changes are stored in the saved game. Synchronization and offsets are stored in the mod settings for each named saved game. Disabling this feature ends synchronization control and keeps edited phases.</p>
      </div><p data-traffic-status role="status"></p><p data-runtime class="hint"></p>`;
    panel.insertBefore(section, panel.querySelector('[data-status]'));
    const find = selector => section.querySelector(selector);
    const selected = new Set();
    let draft = [];
    let editId = null;
    let currentSave = null;
    let plans = {};
    let records;
    try { records = JSON.parse(config.signalPlans || '{}'); } catch { records = {}; }
    const patchedMetadata = new WeakSet();
    let mainTrafficReady = false;
    let loadedSave = null;
    let lastMapSelection = null;
    let lastStatsAt = 0;
    let lastError = null;
    const lastRouting = new WeakMap();
    const marker = document.createElement('div');
    marker.className = 'manipulation-signal-marker';
    marker.hidden = true;
    document.body.appendChild(marker);
    function updateMarker(state) {
        const intersection = state.saveState.intersections[editId];
        const points = intersection?.roadEnds.flatMap(end => end.laneEnds).map(end => {
            const locator = end.lanePointLocator;
            return state.saveState.laneSections[locator.laneSectionId]?.points.pointOrUndefined(locator.pointIndex);
        }).filter(Boolean) || [];
        marker.hidden = panel.hidden || !modern || !points.length;
        if (!marker.hidden) {
            const x = points.reduce((sum, point) => sum + point.x, 0) / points.length;
            const y = points.reduce((sum, point) => sum + point.y, 0) / points.length;
            const screen = game.worldToScreen(x, y);
            if (!screen) { marker.hidden = true; return; }
            marker.style.left = screen.x + 'px'; marker.style.top = screen.y + 'px';
            marker.textContent = 'Traffic light #' + editId;
        }
    }
    function updateRouting(state) {
        const data = { type: 'maipulation-signal-routing', enabled: modern, parallel: parallelLanes(state.saveState.intersections), plans };
        const serialized = JSON.stringify(data);
        for(const worker of [...(state.carWorkers||[]),...(state.pathfindingWorkers||[])]) {
            if(lastRouting.get(worker)!==serialized){worker.postMessage(data);lastRouting.set(worker,serialized);}
        }

    }
    const message = text => { find('[data-traffic-status]').textContent = text; };
    function current() {
        const result = globalThis.__trafficityGameState ?? game.getUndoApi()?.gameState;
        if (!result?.saveState) throw new Error('Open a saved game first.');
        return result;
    }
    let persistQueue = Promise.resolve();
    function persist(changes) {
        persistQueue = persistQueue.catch(() => {}).then(() => modApi.setConfig('maipulation-mod', { ...modApi.getConfig('maipulation-mod', {}), ...changes }));
        persistQueue.catch(error => message('Change active; saving the mod setting failed: ' + error.message));
    }
    function profile(state) {
        const name = game.requireRouterModule('8GfQx')?.getCurrentSaveName?.();
        const key = name ? name + '|' + state.saveState.mapWidth + 'x' + state.saveState.mapHeight : null;
        if (key !== currentSave) { currentSave = key; plans = key ? { ...(records[key] || {}) } : {}; }
        return key;
    }
    function storePlans() {
        const key = profile(current());
        if (!key) { message('Active for this session. Name the saved game to store synchronization permanently.'); return; }
        records[key] = { ...plans };
        persist({ signalPlans: JSON.stringify(records) });
    }

    const nativeController = {
        isEnabled: () => modern,
        getPlan(id) { profile(current()); return plans[id]; },
        status: '',
        redrawNative: null
    };
    function nativeAction(action) {
        return (...args) => {
            let successful = true;
            try { action(...args); nativeController.status = 'Applied.'; }
            catch (error) { successful = false; nativeController.status = error.message; message(error.message); }
            nativeController.redrawNative?.();
            return successful;
        };
    }
    function prepareRouting(state, updated) {
        const previous = state.saveState.intersections[updated.id];
        const canReuse = updated.roadEnds.flatMap(end => end.laneEnds).every(lane => lane.targetLaneSectionIds.every(target => previous?.crossablePathSet?.[lane.lanePointLocator.laneSectionId]?.[target]));
        if (canReuse && previous?.crossablePathSet) {
            // Keep lock indices stable for vehicles already holding a reservation.
            // The routing lists still remove these paths from new route searches.
            updated.crossablePathSet = previous.crossablePathSet;
            updated.crossableLockCount = previous.crossableLockCount;
        } else {
            game.requireRouterModule('hC3Yz').updateIntersectionConnectionPaths(state.saveState.laneSections, updated);
        }
    }
    function publishRouting(state, updated) {
        const save = state.saveState;
        const previous = save.intersections;
        const graphics = game.requireRouterModule('gm1Xv');
        try {
            save.updateWorldState(save.laneSections, save.junctions, { ...previous, [updated.id]: updated });
            if (state.renderer) {
                graphics.updateIntersectionGraphics(state, updated, state.handleEvent);
                graphics.updateCrossablePathVisualization(state);
            }
        } catch (error) {
            save.updateWorldState(save.laneSections, save.junctions, previous);
            throw error;
        }
    }

    nativeController.migratePhase = nativeAction((id, oldId, index) => {
        profile(current());
        const plan = plans[id];
        const next = current().saveState.intersections[id]?.phaseIds[index];
        if (plan?.connections && next != null && next !== oldId) {
            plan.connections[next] = plan.connections[oldId] || JSON.parse(JSON.stringify(plan.baseConnections));
            delete plan.connections[oldId];
            plan.customPhaseIds = plan.customPhaseIds.map(value => value === oldId ? next : value);
            storePlans(); updateSignals();
        }
        if (id === editId) loadEditor();
    });
    function applyLive() {
        try { actions.apply(); return true; }
        catch (error) { message(error.message); return false; }
    }

    function laneEnds(intersection) {
        return intersection.roadEnds.flatMap(end => end.laneEnds).filter(end => end.lanePointLocator.pointIndex > 0);
    }
    function editor() {
        const intersection = current().saveState.intersections[editId];
        const container = find('[data-phases]');
        container.replaceChildren();
        if (!intersection) return;
        const lanes = laneEnds(intersection);
        const base = plans[editId]?.baseConnections || connectionsOf(intersection);
        draft.forEach((phase, index) => {
            const row = document.createElement('fieldset');
            const legend = document.createElement('legend');
            legend.textContent = `Phase ${index + 1}`;
            row.appendChild(legend);
            const seconds = document.createElement('input');
            seconds.type = 'number'; seconds.min = '3'; seconds.max = '300'; seconds.value = phase.durationSeconds;
            seconds.setAttribute('aria-label', `Duration of phase ${index + 1} in seconds`);
            seconds.addEventListener('input', () => {
                const value = Number(seconds.value);
                if (!seconds.value.trim() || !Number.isFinite(value) || value < 3 || value > 300) {
                    seconds.setAttribute('aria-invalid','true');
                    message('Duration must be between 3 and 300 seconds.');
                    return;
                }
                const previous = phase.durationSeconds;
                phase.durationSeconds = value;
                if (!applyLive()) phase.durationSeconds = previous;
                else seconds.setAttribute('aria-invalid','false');
            });
            row.appendChild(seconds);
            const remove = document.createElement('button');
            remove.textContent = 'Remove phase';
            remove.disabled = draft.length <= 1;
            remove.addEventListener('click', () => {
                if (draft.length <= 1) { message('At least one signal phase must remain.'); return; }
                const removed = draft.splice(index,1)[0];
                if (!applyLive()) draft.splice(index,0,removed);
                editor();
            });
            row.appendChild(remove);
            for (const end of lanes) {
                const lane = end.lanePointLocator.laneSectionId;
                const label = document.createElement('label');
                label.className = 'traffic-lane';
                const input = document.createElement('input');
                input.type = 'checkbox'; input.checked = phase.laneEndsWithGreenLight.includes(lane);
                input.addEventListener('change', () => {
                    const previous = [...phase.laneEndsWithGreenLight];
                    phase.laneEndsWithGreenLight = phase.laneEndsWithGreenLight.filter(id => id !== lane);
                    if (input.checked) phase.laneEndsWithGreenLight.push(lane);
                    if (!applyLive()) { phase.laneEndsWithGreenLight = previous; input.checked = previous.includes(lane); }
                });
                label.append(input, document.createTextNode(`Lane ${lane} → ${(end.targetLaneSectionIds || []).join(', ')} green`));
                row.appendChild(label);
            }
            row.appendChild(phaseConnectionEditor(current(), intersection, phase, base, game, applyLive, applyLive));
            container.appendChild(row);
        });
    }
    function loadEditor() {
        editId = Number(find('[data-edit]').value);
        const state = current(); profile(state);
        const intersection = state.saveState.intersections[editId];
        draft = intersection ? intersection.phaseIds.map(id => ({ id, durationSeconds: intersection.phases[id].durationSeconds, laneEndsWithGreenLight: [...intersection.phases[id].laneEndsWithGreenLight], connections: plans[editId]?.customPhaseIds?.includes(id) ? JSON.parse(JSON.stringify(plans[editId].connections[id])) : null })) : [];
        find('[data-selected-signal]').textContent = intersection ? 'Editing traffic light #' + editId + ' · highlighted on the map' : 'No traffic light selected';
        find('[data-offset]').value = plans[editId]?.offset || 0;
        updateMarker(state);
        editor();
    }
    function refreshList() {
        const state = current(); profile(state);
        const list = find('[data-signals]'); const select = find('[data-edit]');
        list.replaceChildren(); select.replaceChildren();
        const intersections = Object.values(state.saveState.intersections).filter(item => item.phaseIds?.length);
        for (const intersection of intersections) {
            const label = document.createElement('label'); label.className = 'traffic-lane';
            const input = document.createElement('input'); input.type = 'checkbox'; input.checked = selected.has(intersection.id);
            input.addEventListener('change', () => { if (input.checked) selected.add(intersection.id); else selected.delete(intersection.id); });
            label.append(input, document.createTextNode(`Traffic light #${intersection.id} · ${intersection.phaseIds.length} phases`)); list.appendChild(label);
            const option = document.createElement('option'); option.value = intersection.id; option.textContent = `Traffic light #${intersection.id}`; select.appendChild(option);
        }
        for (const id of selected) if (!state.saveState.intersections[id]) selected.delete(id);
        if (intersections.some(item => item.id === editId)) select.value = editId;
        loadEditor();
        message(`${intersections.length} traffic lights found.`);
    }
    function hookMetadata(state) {
        const metadata = state.saveState.intersectionMetadata;
        if (!metadata || patchedMetadata.has(metadata)) return;
        const originals = {};
        for (const name of ['setCurrentPhaseId', 'setTimeRemainingInPhase', 'setAreAmberLightsShowing']) originals[name] = metadata[name].bind(metadata);
        function enforce(id) {
            if (!modern || !plans[id]) return false;
            const intersection = state.saveState.intersections[id];
            if (!intersection) return false;
            const phase = signalAt(intersection, state.saveState.gameTimeBuffer[0], plans[id].offset);
            if (!phase) return false;
            originals.setCurrentPhaseId(id, phase.id);
            originals.setTimeRemainingInPhase(id, phase.remaining);
            originals.setAreAmberLightsShowing(id, phase.amber);
            return true;
        }
        for (const name of Object.keys(originals)) metadata[name] = (id, value) => { if (!enforce(id)) originals[name](id, value); };
        patchedMetadata.add(metadata);
    }
    function updateSignals() {
        const state = current(); profile(state); hookMetadata(state);
        updateRouting(state);
        updateMarker(state);
        if (!modern) return;
        const graphics = game.requireRouterModule('gm1Xv');
        for (const id of Object.keys(plans)) {
            const intersection = state.saveState.intersections[id];
            if (!intersection) continue;
            state.saveState.intersectionMetadata.setCurrentPhaseId(Number(id), 0);
            graphics?.updateIntersectionTrafficLightCircles?.(state, intersection);
        }
    }
    find('[data-intelligent]').checked = intelligent;
    find('[data-modern]').checked = modern;
    find('[data-signal-tools]').hidden = !modern;
    find('[data-intelligent]').addEventListener('change', event => {
        try {
            const state = current();
            if (!mainTrafficReady || state.carWorkers.some(worker => !trafficHook.workers.has(worker))) throw new Error('Reload the game and open the saved game to enable traffic use in all simulation workers.');
            intelligent = event.target.checked;
            Atomics.store(trafficHook.control, 1, intelligent ? 1 : 0);
            trafficHook.enabled = intelligent;
            globalThis.__intelligentTraffic = intelligent;
            for (const worker of state.carWorkers) worker.postMessage({ type: 'maipulation-traffic-use', enabled: intelligent });
            persist({ intelligentTraffic: intelligent });
            message(intelligent ? 'Intelligent traffic use enabled.' : 'Standard lane selection enabled.');
        } catch (error) { event.target.checked = intelligent; message(error.message); }
    });
    find('[data-modern]').addEventListener('change', event => {
        modern = event.target.checked; Atomics.store(trafficHook.control, 2, modern ? 1 : 0); find('[data-signal-tools]').hidden = !modern;
        persist({ modernTrafficLights: modern });
        try { refreshList(); updateSignals(); } catch (error) { message(error.message); }
    });
    find('[data-offset]').addEventListener('input', () => { if (find('[data-offset]').value.trim()) applyLive(); });
    find('[data-edit]').addEventListener('change', () => { try { loadEditor(); } catch (error) { message(error.message); } });
    const actions = {
        refresh: refreshList,
        pick() {
            const state = current(); const id = state.uiMode?.intersectionId;
            if (id == null || !state.saveState.intersections[id]) throw new Error('Open a traffic light editor on the map first.');
            selected.add(id); editId = id; refreshList();
        },
        add() { draft.push({ durationSeconds: 10, laneEndsWithGreenLight: [], connections: null }); if (!applyLive()) draft.pop(); editor(); },
        restore() {
            const state = current(); profile(state);
            const intersection = state.saveState.intersections[editId];
            const plan = plans[editId];
            if (!intersection) throw new Error('Select a traffic light.');
            if (plan?.baseConnections) {
                const updated = withConnections(intersection, plan.baseConnections);
                prepareRouting(state, updated);
                publishRouting(state, updated);
                delete plan.connections; delete plan.baseConnections; delete plan.customPhaseIds;
                storePlans(); state.requestUiRefresh();
            }
            for (const phase of draft) phase.connections = null;
            editor(); updateSignals();
            message('All custom phase connections at this junction were reset to the general diagram.');
        },
        apply() {
            const state = current(); const save = state.saveState; const intersection = save.intersections[editId];
            if (!intersection) throw new Error('Select a traffic light.');
            const offset = Number(find('[data-offset]').value);
            if (!Number.isFinite(offset) || offset < 0 || offset > 3600) throw new Error('Offset must be between 0 and 3600 seconds.');
            if (!draft.length || draft.length > 16 || draft.some(phase => !Number.isFinite(phase.durationSeconds) || phase.durationSeconds < 3 || phase.durationSeconds > 300)) throw new Error('Create 1–16 phases, each lasting 3–300 seconds.');
            const allowed = new Set(laneEnds(intersection).map(end => end.lanePointLocator.laneSectionId));
            if (draft.some(phase => phase.laneEndsWithGreenLight.some(id => !allowed.has(id)))) throw new Error('Lane connections changed. Refresh the traffic light list.');
            profile(state);
            const hasCustom = draft.some(phase => phase.connections != null);
            if (hasCustom && !currentSave) throw new Error('Name and save the game first to preserve custom phase connections.');
            if (hasCustom && state.carWorkers.some(worker => !trafficHook.workers.has(worker))) throw new Error('Reload the game to enable custom phase routing in all simulation workers.');
            const baseConnections = plans[editId]?.baseConnections || connectionsOf(intersection);
            const targetIds = new Set(intersection.roadEnds.flatMap(end => end.laneEnds).filter(end => end.lanePointLocator.pointIndex === 0).map(end => end.lanePointLocator.laneSectionId));
            for (const phase of draft) {
                if (!phase.connections) continue;
                for (const [source, targets] of Object.entries(phase.connections)) {
                    if (!allowed.has(Number(source)) || !Array.isArray(targets) || targets.some(target => !targetIds.has(target))) throw new Error('Invalid phase connection. Refresh the traffic light list.');
                }
            }
            const connections = {};
            const union = Object.fromEntries([...allowed].map(id => [id, []]));
            const phases = {}; const phaseIds = [];
            let nextId = save.nextIntersectionPhaseId;
            for (const phase of draft) {
                const id = intersection.phases[phase.id] ? phase.id : nextId++;
                const mapping = phase.connections || baseConnections;
                connections[id] = JSON.parse(JSON.stringify(mapping));
                for (const source of allowed) union[source] = [...new Set([...union[source], ...(mapping[source] || [])])];
                const green = [...phase.laneEndsWithGreenLight];
                phaseIds.push(id); phases[id] = { id, durationSeconds: phase.durationSeconds, laneEndsWithGreenLight: green };
            }
            const updated = { ...withConnections(intersection, hasCustom ? union : baseConnections), phaseIds, phases };
            const paths = game.requireRouterModule('hC3Yz');
            if (typeof paths?.updateIntersectionConnectionPaths !== 'function') throw new Error('Phase connections do not support this game version.');
            prepareRouting(state, updated);
            for (const [source, targets] of Object.entries(hasCustom ? union : baseConnections)) {
                if (targets.some(target => !updated.crossablePathSet[source]?.[target])) throw new Error('A selected connection cannot be built geometrically. Choose another exit lane.');
            }
            publishRouting(state, updated);
            save.nextIntersectionPhaseId = nextId;
            draft.forEach((phase,index) => { phase.id = phaseIds[index]; });
            profile(state); plans[editId] = hasCustom ? { offset, connections, baseConnections, customPhaseIds: phaseIds.filter((id, index) => draft[index].connections != null) } : { offset };
            const metadata = save.intersectionMetadata;
            const activeId = metadata.getCurrentPhaseId(editId);
            if (!updated.phases[activeId]) metadata.initializeForIntersection(updated);
            else if (updated.phases[activeId].durationSeconds !== intersection.phases[activeId]?.durationSeconds) {
                metadata.setTimeRemainingInPhase(editId, Math.min(metadata.getTimeRemainingInPhase(editId), updated.phases[activeId].durationSeconds));
            }
            state.requestUiRefresh(); storePlans(); updateSignals(); nativeController.redrawNative?.();
            message('Change applied immediately. Save the game to keep it.');
        },
        sync() {
            const state = current(); profile(state);
            const targets = [...selected].map(id => state.saveState.intersections[id]).filter(Boolean);
            if (targets.length < 2) throw new Error('Select at least two traffic lights.');
            const signature = item => item.phaseIds.map(id => item.phases[id].durationSeconds).join(',');
            if (targets.some(item => signature(item) !== signature(targets[0]))) throw new Error('Set matching phase counts and durations for these traffic lights first.');
            const epoch = state.saveState.gameTimeBuffer[0];
            for (const item of targets) plans[item.id] = { ...plans[item.id], offset: epoch % targets[0].phaseIds.reduce((sum, id) => sum + targets[0].phases[id].durationSeconds, 0) };
            updateSignals(); storePlans();
            message(`${targets.length} traffic lights synchronized. Set individual offsets in the editor.`);
        },
        unsync() { profile(current()); for (const id of selected) { if (plans[id]?.connections) plans[id].offset = 0; else delete plans[id]; } storePlans(); message('Synchronization unlinked for the selection.'); }
    };
    section.addEventListener('click', event => {
        const button = event.target.closest('button[data-action]');
        if (!button) return;
        event.stopPropagation();
        try { actions[button.dataset.action]?.(); } catch (error) { message(error.message); }
    });
    game.on('ready', () => {
        try { installNativeSignals(game, nativeController); } catch (error) { message(error.message); }
        globalThis.__intelligentTraffic = intelligent;
        const module = game.requireRouterModule('ctjqx');
        const original = module?.runLaneSwitchingPeriodicCheck;
        if (typeof original === 'function') {
            // Only the final choice inside the game's approved funnel is changed.
            const source = original.toString();
            const needle = 'K=f(z,J,a,i)';
            if (source.includes(needle)) {
                // The function closes over bundle helpers, so its main-thread implementation
                // is left intact; active car simulation is performed in patched workers.
                mainTrafficReady = true;
            }
        }
        try { refreshList(); updateSignals(); } catch (error) { message(error.message); }
        const timer = window.setInterval(() => {
            try {
                const state = current();
                if (loadedSave !== state.saveState) {
                    loadedSave = state.saveState;
                    lastMapSelection = null;
                    refreshList();
                }
                const clickedId = state.uiMode?.mode === 'intersection editing' ? state.uiMode.intersectionId : null;
                if (clickedId != null && clickedId !== lastMapSelection) {
                    lastMapSelection = clickedId;
                    editId = clickedId;
                    if (![...find('[data-edit]').options].some(option => Number(option.value) === clickedId)) refreshList();
                    find('[data-edit]').value = String(clickedId);
                    loadEditor();
                }
                updateSignals();
                const signal = state.saveState.intersections[editId];
                if (signal) {
                    const metadata = state.saveState.intersectionMetadata;
                    const activeId = metadata.getCurrentPhaseId(editId);
                    const index = signal.phaseIds.indexOf(activeId) + 1;
                    find('[data-live-signal]').textContent = 'Traffic light #' + editId + ' · Active phase ' + index + ' · ' + metadata.getTimeRemainingInPhase(editId).toFixed(1) + ' s remaining';
                }
                if (Date.now() - lastStatsAt > 2000) {
                    lastStatsAt = Date.now();
                    for (const worker of [...(state.carWorkers || []),...(state.pathfindingWorkers||[])]) worker.postMessage({ type: 'maipulation-runtime-stats' });
                    const workers = [...(state.carWorkers || []), ...(state.happinessWorkers || []), ...(state.pathfindingWorkers || [])];
                    const ready = workers.filter(worker => trafficHook.info.get(worker)?.ready).length;
                    let checks = 0, changes = 0, held = 0, blocked = 0, routes=0, replans=0, applied=0, noRoute=0;
                    for (const worker of [...(state.carWorkers || []),...(state.pathfindingWorkers||[])]) {
                        const stats = trafficHook.info.get(worker)?.stats || {};
                        checks += stats.checks || 0; changes += stats.changes || 0; held += stats.heldAtSignal || 0; blocked += stats.blockedDirections || 0;routes+=stats.routeEvaluations||0;replans+=stats.replans||0;applied+=stats.replansApplied||0;noRoute+=stats.noLegalRoute||0;
                    }
                    find('[data-runtime]').textContent = 'Simulation connected: ' + ready + '/' + workers.length + ' workers · Lane checks ' + checks + ' · Recommendations changed ' + changes + ' · Lane held near signal ' + held + ' · Forbidden turns held ' + blocked + (trafficHook.errors.length ? ' · Error: ' + trafficHook.errors[0] : '');
                }
                lastError = null;
            } catch (error) {
                if (error.message !== lastError) { message(error.message); lastError = error.message; }
            }
        }, 150);
        window.addEventListener('beforeunload', () => window.clearInterval(timer), { once: true });
    });
}
