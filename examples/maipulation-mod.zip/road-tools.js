import { roadExtent, pointAt } from './road-rules.js';
import { facilityAtPoint, facilityLabel, facilityCorners, serviceFacilityIds } from './service-access.js';

const TYPES={service:'Service access',closure:'Road closure',stop:'Stop sign',left:'Left only',right:'Right only',straight:'Straight only','prefer-left':'↖ Prefer left','prefer-right':'↗ Prefer right','merge-left':'↖ Require left merge','merge-right':'↗ Require right merge'};
const COLORS={service:'#ff9f43',closure:'#ff726c',stop:'#ff726c',left:'#b899ff',right:'#66cbff',straight:'#6ae2c1','prefer-left':'#66cbff','prefer-right':'#66cbff','merge-left':'#f4c542','merge-right':'#f4c542'};
const directional=type=>['left','right','straight'].includes(type);

export function createLaneIndex(network) {
    const buckets=new Map(),size=80;
    for(const lane of Object.values(network.laneSections)) {
        for(let i=0;i<lane.points.length;i+=5) {
            const p=lane.points.pointOrUndefined(i),key=Math.floor(p.x/size)+','+Math.floor(p.y/size);
            if(!buckets.has(key))buckets.set(key,[]);buckets.get(key).push({laneId:lane.id,index:i});
        }
    }
    return {network:network.laneSections,buckets,size};
}

export function nearestLane(index,network,x,y,tolerance=12) {
    let best=null,minimum=tolerance*tolerance;
    const bx=Math.floor(x/index.size),by=Math.floor(y/index.size),seen=new Set();
    for(let dx=-1;dx<=1;dx++)for(let dy=-1;dy<=1;dy++)for(const item of index.buckets.get((bx+dx)+','+(by+dy))||[]) {
        const lane=network.laneSections[item.laneId];
        for(let i=Math.max(0,item.index-5);i<Math.min(lane.points.length,item.index+6);i++) {
            const key=lane.id+':'+i;if(seen.has(key))continue;seen.add(key);
            const p=lane.points.pointOrUndefined(i),d=(p.x-x)**2+(p.y-y)**2;
            if(d<minimum) {minimum=d;best={laneId:lane.id,pointIndex:i,x:p.x,y:p.y,a:p.a,elevation:p.elevation};}
        }
    }
    return best;
}

export function rebindRoadSigns(signs,index,network) {
    return signs.map(sign=>{
        const old=network.laneSections[sign.laneId]?.points.pointOrUndefined(sign.pointIndex);
        if(old&&Math.hypot(old.x-sign.x,old.y-sign.y)<2&&Math.abs(Math.sin(old.a-sign.a))<.1)return {...sign,valid:true};
        const match=nearestLane(index,network,sign.x,sign.y,3);
        if(match&&Math.abs(Math.atan2(Math.sin(match.a-sign.a),Math.cos(match.a-sign.a)))<.15&&Math.abs((match.elevation||0)-(sign.elevation||0))<.5)return {...sign,...match,valid:true};
        return {...sign,valid:false};
    });
}

export function installRoadTools(modApi,game,config,panel,runtime) {
    let enabled=config.roadToolsEnabled===true,tool=null,selected=null,hover=null,index=null,save=null,key=null,signs=[];
    let defaultDistance=Math.max(1,Math.min(10000,Number(config.roadToolDistance)||300));
    let records;try{records=JSON.parse(config.roadToolRecords||'{}');}catch{records={};}
    let queue=Promise.resolve(),previewUntil=0,revision=0,lastError=null,pickingFacility=false;
    const sent=new WeakMap(),nodes=new Map();
    const section=document.createElement('section');section.dataset.topic='road-tools';
    section.innerHTML=`<h3>Lane tools</h3><label class="traffic-toggle"><input type="checkbox" data-road-enable> Enable lane tools</label>
      <p class="hint">Each sign applies to one lane. New closures and changed direction rules immediately trigger checks for affected routes. Left-click to place; right-click to remove on that lane. Esc stops placement. Blue arrows prefer a merge without forcing a stop. Yellow arrows require a merge and wait for a safe gap at the marker. The destination lane must be legal for the vehicle route. Each 45° sign applies once per vehicle passage and is completed after the lane change. It does not permanently bind the vehicle to a lane. Right-click or use Remove sign to remove the placed rule.</p>
      <div class="road-tool-grid" data-road-tools></div><button data-road-finish>Stop placing</button>
      <label class="road-distance">Range for new direction signs <input data-road-default type="number" min="1" max="10000" step="10" aria-label="Default range"> Game units</label>
      <p class="hint">Direction signs apply up to the next junction within the configured range. Straight only also prohibits lane changes into or out of the highlighted section; vehicles must get into the correct lane beforehand. Road closures and stop signs apply at the marker. Stop signs require a 2-second simulation stop, followed by the normal right-of-way rules.</p>
      <h4>Edit placed sign</h4><select data-road-selected aria-label="Placed sign"></select>
      <label class="road-distance" data-road-distance-label>Maximum distance <input data-road-distance type="number" min="1" max="10000" step="10" aria-label="Range of this sign"> Game units</label>
      <fieldset data-service hidden><legend>Linked facilities</legend><p class="hint">Only workers and deliveries serving linked facilities may pass, including their return trips. Other traffic must find a legal alternative. With no valid linked facility, this sign is inactive.</p><button data-service-pick>Pick facility on map</button><div data-service-list></div></fieldset><p data-road-detail class="hint"></p><div class="road-tool-actions"><button data-road-preview>Show affected section · 10 s</button><button data-road-remove>Remove sign</button></div>
      <p class="hint">The preview highlights only the affected lane. Disabling lane tools suspends their rules and keeps the signs. Signs are stored in the mod settings for each named saved game.</p>
      <p data-road-status role="status"></p><p data-road-runtime class="hint"></p>`;
    panel.insertBefore(section,panel.querySelector('[data-status]'));
    const find=selector=>section.querySelector(selector),status=text=>{find('[data-road-status]').textContent=text;};
    const overlay=document.createElement('div');overlay.className='manipulation-road-overlay';
    const svg=document.createElementNS('http://www.w3.org/2000/svg','svg');svg.classList.add('manipulation-road-range');overlay.appendChild(svg);
    const range=document.createElementNS('http://www.w3.org/2000/svg','g');svg.appendChild(range);
    const ghost=document.createElement('div');ghost.className='manipulation-road-marker road-ghost';ghost.hidden=true;overlay.appendChild(ghost);
    const selectedLabel=document.createElement('div');selectedLabel.className='manipulation-road-label';selectedLabel.hidden=true;overlay.appendChild(selectedLabel);
    document.body.appendChild(overlay);
    function current(){return globalThis.__trafficityGameState??game.getUndoApi()?.gameState;}
    function persist(changes) {
        queue=queue.catch(()=>{}).then(()=>modApi.setConfig('maipulation-mod',{...modApi.getConfig('maipulation-mod',{}),...changes}));
        queue.catch(error=>status('Active; saving failed: '+error.message));
    }
    function store(){if(!key){status('Active for this session. Name the saved game to store these signs permanently.');return;}records[key]=signs.map(({valid,...sign})=>sign);persist({roadToolRecords:JSON.stringify(records)});}
    function profile(state) {
        const name=game.requireRouterModule('8GfQx')?.getCurrentSaveName?.();
        const next=name?name+'|'+state.saveState.mapWidth+'x'+state.saveState.mapHeight:null;
        const changedSave=save!==state.saveState;
        if(changedSave||key!==next) {
            // Save-as in the same loaded world keeps current placements.
            if(changedSave)signs=(records[next]||[]).map(sign=>({...sign}));
            save=state.saveState;key=next;index=null;selected=signs[0]?.id??null;revision++;renderList();
            if(!changedSave&&key)store();
        }
        if(!index||index.network!==state.saveState.laneSections) {
            index=createLaneIndex(state.saveState);signs=rebindRoadSigns(signs,index,state.saveState);revision++;renderList();
        }
    }
    function setTool(value){pickingFacility=false;tool=value;hover=null;ghost.hidden=true;renderButtons();status(value?'Active: '+TYPES[value]+' · Left-click one lane to place; right-click to remove.':'Placement stopped.');}
    function renderButtons(){for(const button of find('[data-road-tools]').children){button.disabled=!enabled;button.setAttribute('aria-pressed',String(tool===button.dataset.roadType));}find('[data-road-finish]').disabled=!tool&&!pickingFacility;find('[data-road-enable]').checked=enabled;}
    function renderList() {
        const select=find('[data-road-selected]');select.replaceChildren();
        if(!signs.length){const option=document.createElement('option');option.textContent='No signs placed yet';option.value='';select.appendChild(option);}
        for(const sign of signs){const option=document.createElement('option');option.value=sign.id;option.textContent=TYPES[sign.type]+' · Lane #'+sign.laneId+' · Point '+sign.pointIndex+(sign.valid===false?' · Road changed':'');select.appendChild(option);}
        if(!signs.some(sign=>sign.id===selected))selected=signs[0]?.id??null;
        select.value=selected||'';renderSelection();
    }
    function renderSelection() {
        const sign=signs.find(item=>item.id===selected),isDirection=sign&&directional(sign.type);
        renderFacilities(sign);
        find('[data-road-distance-label]').hidden=!isDirection;
        find('[data-road-distance]').value=sign?.maxDistance||defaultDistance;
        find('[data-road-preview]').disabled=!sign||sign.valid===false;
        find('[data-road-remove]').disabled=!sign;
        if(!sign){find('[data-road-detail]').textContent='';return;}
        if(sign.valid===false){find('[data-road-detail]').textContent='Road changed: this sign is suspended. Place it again or remove it.';return;}
        const extent=isDirection&&save?roadExtent(save,sign,signs.filter(s=>s.valid!==false)):null;
        const ends={intersection:'next signalized junction',junction:'next junction',range:'maximum distance',sign:'next direction sign',end:'lane end'};
        find('[data-road-detail]').textContent=isDirection?'Lane #'+sign.laneId+' · Affected distance: '+Math.round(extent?.distance||0)+' Game units · Ends at: '+(ends[extent?.ending?.kind]||'lane end')+'.'+(sign.type==='straight'?' Lane changes are also prohibited in this section.':''):'Lane #'+sign.laneId+' · '+(sign.type.startsWith('merge-')?'One required merge at the marker; wait for a safe gap if needed.':sign.type.startsWith('prefer-')?'Prefer the adjacent lane if the route permits and a safe gap is available.':'point rule at this marker.');
    }

    function renderFacilities(sign){
        find('[data-service]').hidden=sign?.type!=='service';
        const list=find('[data-service-list]');list.replaceChildren();
        find('[data-service-pick]').textContent=pickingFacility?'Cancel facility selection':'Pick facility on map';
        if(sign?.type!=='service')return;
        for(const id of sign.allowedBuildingIds||[]){
            const row=document.createElement('div');row.className='road-facility-row';
            const name=document.createElement('input');name.type='text';name.setAttribute('aria-label','Facility name');name.value=sign.facilityNames?.[id]||'Linked facility';
            if(!save?.buildings?.[id])name.value+=' (removed)';
            name.addEventListener('change',()=>{sign.facilityNames={...sign.facilityNames,[id]:name.value.trim()||'Linked facility'};store();draw();});
            const remove=document.createElement('button');remove.textContent='Unlink';remove.addEventListener('click',()=>{sign.allowedBuildingIds=sign.allowedBuildingIds.filter(item=>item!==id);revision++;store();renderSelection();publish(current());draw();});
            row.append(name,remove);list.appendChild(row);
        }
        if(!serviceFacilityIds(sign,save||{}).length){const hint=document.createElement('p');hint.className='hint';hint.textContent='Inactive: link a facility on the map.';list.appendChild(hint);}
    }
    function drawFacilities(sign){
        if(sign?.type!=='service'||panel.hidden&&Date.now()>previewUntil)return;
        for(const id of serviceFacilityIds(sign,save)){
            const building=save.buildings[id],points=facilityCorners(building.footprint).map(p=>game.worldToScreen(p.x,p.y));if(points.some(p=>!p))continue;
            const polygon=document.createElementNS(svg.namespaceURI,'polygon');polygon.setAttribute('points',points.map(p=>p.x+','+p.y).join(' '));polygon.setAttribute('fill','#ff9f4333');polygon.setAttribute('stroke','#ff9f43');polygon.setAttribute('stroke-width','3');range.appendChild(polygon);
            const center=game.worldToScreen(building.footprint.centerX,building.footprint.centerY);if(!center)continue;
            const text=document.createElementNS(svg.namespaceURI,'text');text.setAttribute('x',center.x);text.setAttribute('y',center.y);text.setAttribute('text-anchor','middle');text.setAttribute('fill','#fff');text.setAttribute('stroke','#202734');text.setAttribute('stroke-width','3');text.setAttribute('paint-order','stroke');text.textContent=sign.facilityNames?.[id]||facilityLabel(building,game);range.appendChild(text);
        }
    }
    find('[data-service-pick]').addEventListener('click',()=>{const sign=signs.find(item=>item.id===selected);if(!enabled||sign?.type!=='service')return;tool=null;hover=null;pickingFacility=!pickingFacility;renderButtons();renderSelection();status(pickingFacility?'Click a facility on the map to link it. Right-click or Esc cancels.':'Facility selection cancelled.');});

    function publish(state) {
        const data={type:'maipulation-road-tools',enabled,revision,signs:signs.filter(sign=>sign.valid!==false).map(({valid,facilityNames,...sign})=>sign)};
        const serialized=JSON.stringify(data);
        for(const worker of [...(state.carWorkers||[]),...(state.pathfindingWorkers||[])]) {
            if(runtime.info.get(worker)?.ready&&sent.get(worker)!==serialized){worker.postMessage(data);sent.set(worker,serialized);}
        }
    }
    function symbol(node,type,angle=0) {
        node.dataset.roadType=type;node.style.setProperty('--road-angle',(angle*180/Math.PI+90)+'deg');
        node.innerHTML=type==='service'?'<span class="road-service" title="Service access">⚒</span>':type==='closure'?'<span class="road-no-entry"></span>':type==='stop'?'<span class="road-stop">STOP</span>':'<span class="road-direction">'+({left:'↰',right:'↱',straight:'↑','prefer-left':'↖','merge-left':'↖','prefer-right':'↗','merge-right':'↗'}[type])+'</span>';
    }
    function position(node,point){const screen=game.worldToScreen(point.x,point.y);node.hidden=!screen;if(screen){node.style.left=screen.x+'px';node.style.top=screen.y+'px';}}
    function draw() {
        overlay.hidden=!save;
        const camera=game.getCameraState?.(),zoom=camera?.zoom||1;
        const validIds=new Set();
        for(const sign of signs){if(sign.valid===false)continue;validIds.add(sign.id);let node=nodes.get(sign.id);if(!node){node=document.createElement('div');node.className='manipulation-road-marker';overlay.appendChild(node);nodes.set(sign.id,node);}symbol(node,sign.type,sign.a);node.style.setProperty('--road-marker-scale',Math.min(1,Math.max(.35,zoom*.75)));position(node,sign);node.classList.toggle('road-disabled',!enabled);node.classList.toggle('road-selected',selected===sign.id&&(!panel.hidden||Date.now()<previewUntil));}
        for(const [id,node]of nodes)if(!validIds.has(id)){node.remove();nodes.delete(id);}
        ghost.hidden=!hover||!tool||!enabled;if(!ghost.hidden){symbol(ghost,tool,hover.a);position(ghost,hover);}
        const editing=signs.find(sign=>sign.id===selected&&sign.valid!==false);
        selectedLabel.hidden=!editing||(panel.hidden&&Date.now()>previewUntil);
        if(!selectedLabel.hidden){const screen=game.worldToScreen(editing.x,editing.y);selectedLabel.hidden=!screen;if(screen){selectedLabel.style.left=Math.max(130,Math.min(window.innerWidth-130,screen.x))+'px';selectedLabel.style.top=Math.max(40,screen.y-18)+'px';selectedLabel.textContent=TYPES[editing.type]+' · Lane #'+editing.laneId+' · Point '+editing.pointIndex;selectedLabel.dataset.required=String(editing.type.startsWith('merge-'));}}
        range.replaceChildren();
        drawFacilities(editing);
        const sign=signs.find(item=>item.id===selected&&item.valid!==false);
        if(!sign||Date.now()>previewUntil)return;
        if(!directional(sign.type)) {
            const screen=game.worldToScreen(sign.x,sign.y);if(!screen)return;
            const circle=document.createElementNS(svg.namespaceURI,'circle');circle.setAttribute('cx',screen.x);circle.setAttribute('cy',screen.y);circle.setAttribute('r',Math.max(12,zoom*10));circle.setAttribute('fill',COLORS[sign.type]+'88');range.appendChild(circle);return;
        }
        const extent=roadExtent(save,sign,signs.filter(s=>s.valid!==false));
        for(const segment of extent.segments) {
            const lane=save.laneSections[segment.laneId],points=[];
            for(let i=segment.from;i<segment.to;i+=3){const p=pointAt(lane,i),s=game.worldToScreen(p.x,p.y);if(s)points.push(s.x+','+s.y);}
            const last=pointAt(lane,segment.to);let lastScreen=game.worldToScreen(last.x,last.y);if(lastScreen)points.push(lastScreen.x+','+lastScreen.y);
            if(segment.connectorEnd){lastScreen=game.worldToScreen(segment.connectorEnd.x,segment.connectorEnd.y);if(lastScreen)points.push(lastScreen.x+','+lastScreen.y);}
            const line=document.createElementNS(svg.namespaceURI,'polyline');line.setAttribute('points',points.join(' '));line.setAttribute('fill','none');line.setAttribute('stroke',COLORS[sign.type]);line.setAttribute('stroke-width',Math.max(2,(game.getConstants?.().laneWidth||20)*zoom*.65));line.setAttribute('stroke-opacity','.65');line.setAttribute('stroke-linecap','butt');range.appendChild(line);
            if(lastScreen&&segment===extent.segments.at(-1)){const dot=document.createElementNS(svg.namespaceURI,'circle');dot.setAttribute('cx',lastScreen.x);dot.setAttribute('cy',lastScreen.y);dot.setAttribute('r',Math.max(4,zoom*5));dot.setAttribute('fill','#fff');range.appendChild(dot);}
        }
    }
    for(const [type,label]of Object.entries(TYPES)){const button=document.createElement('button');button.textContent=label;button.dataset.roadType=type;button.addEventListener('click',()=>setTool(tool===type?null:type));find('[data-road-tools]').appendChild(button);}
    find('[data-road-enable]').addEventListener('change',event=>{enabled=event.target.checked;if(runtime.control?.length>=4)Atomics.store(runtime.control,3,enabled?1:0);if(!enabled)setTool(null);revision++;persist({roadToolsEnabled:enabled});renderButtons();const state=current();if(state?.saveState)publish(state);});
    find('[data-road-default]').value=defaultDistance;
    find('[data-road-default]').addEventListener('input',event=>{const value=Number(event.target.value);if(Number.isFinite(value)&&value>=1&&value<=10000){defaultDistance=value;persist({roadToolDistance:value});}});
    find('[data-road-distance]').addEventListener('input',event=>{const value=Number(event.target.value),sign=signs.find(item=>item.id===selected);if(sign&&directional(sign.type)&&Number.isFinite(value)&&value>=1&&value<=10000){sign.maxDistance=value;revision++;store();previewUntil=Date.now()+10000;renderSelection();publish(current());draw();}});
    find('[data-road-selected]').addEventListener('change',event=>{pickingFacility=false;selected=event.target.value;renderSelection();});
    find('[data-road-finish]').addEventListener('click',()=>setTool(null));
    find('[data-road-preview]').addEventListener('click',()=>{previewUntil=Date.now()+10000;draw();status('Affected section highlighted for 10 seconds. The white dot marks the end.');});
    function remove(id){pickingFacility=false;signs=signs.filter(sign=>sign.id!==id);revision++;store();renderList();publish(current());draw();}
    find('[data-road-remove]').addEventListener('click',()=>{if(selected)remove(selected);});
    const onMap=event=>event.target?.tagName?.toLowerCase()==='canvas'&&!event.target.closest?.('.manipulation-panel');
    function snap(event){const state=current();if(!state?.saveState)return null;profile(state);const p=game.screenToWorld(event.clientX,event.clientY);return p?nearestLane(index,state.saveState,p.x,p.y,(game.getConstants?.().laneWidth||20)*.55):null;}
    modApi.onMouse('pointermove',event=>{if(enabled&&tool&&onMap(event)){hover=snap(event);draw();}else{hover=null;ghost.hidden=true;}});
    modApi.onMouse('pointerdown',event=>{
        if(!enabled||(!tool&&!pickingFacility)||!onMap(event)||![0,2].includes(event.button))return;
        event.preventDefault();event.stopImmediatePropagation();
        try {
            if(pickingFacility){
                if(event.button===2){pickingFacility=false;renderSelection();return;}
                const state=current();if(!state?.saveState)return;profile(state);
                const point=game.screenToWorld(event.clientX,event.clientY),building=point&&facilityAtPoint(save.buildings,point.x,point.y);
                const sign=signs.find(item=>item.id===selected&&item.type==='service');
                if(!sign)return;
                if(!building){status('Click inside the facility footprint. Right-click cancels.');return;}
                sign.allowedBuildingIds=[...new Set([...(sign.allowedBuildingIds||[]),building.id])];
                sign.facilityNames={...sign.facilityNames,[building.id]:facilityLabel(building,game)};
                pickingFacility=false;revision++;store();renderButtons();renderSelection();publish(state);draw();status('Facility linked. Pick another facility to add more.');return;
            }
            const match=snap(event);if(!match){status('Click directly on a driving lane.');return;}
            const nearby=signs.filter(sign=>sign.laneId===match.laneId&&Math.hypot(sign.x-match.x,sign.y-match.y)<30).sort((a,b)=>Math.hypot(a.x-match.x,a.y-match.y)-Math.hypot(b.x-match.x,b.y-match.y))[0];
            if(event.button===2){if(nearby){remove(nearby.id);status('Removed sign only on lane #'+match.laneId+'.');}return;}
            const sign={id:nearby?.id||crypto.randomUUID(),...match,type:tool,maxDistance:defaultDistance,valid:true};
            if(nearby)signs=signs.map(item=>item.id===nearby.id?sign:item);else signs.push(sign);
            selected=sign.id;revision++;previewUntil=Date.now()+10000;store();renderList();publish(current());draw();status(TYPES[tool]+' on lane #'+match.laneId+' placed.');
        }catch(error){status(error.message);}
    });
    for(const type of ['mousedown','mouseup','pointerup','click','contextmenu'])modApi.onMouse(type,event=>{if(enabled&&(tool||pickingFacility)&&onMap(event)&&[0,2].includes(event.button)){event.preventDefault();event.stopImmediatePropagation();}});
    modApi.bindKey('Escape',()=>{if(tool||pickingFacility){setTool(null);renderSelection();return true;}return false;});
    renderButtons();renderList();
    const timer=window.setInterval(()=>{
        try{const state=current();if(!state?.saveState){overlay.hidden=true;return;}profile(state);publish(state);draw();if(!panel.hidden){const workers=[...(state.carWorkers||[]),...(state.pathfindingWorkers||[])],ready=workers.filter(worker=>runtime.info.get(worker)?.ready).length;find('[data-road-runtime]').textContent=signs.filter(sign=>sign.valid!==false).length+' placed signs · Simulation connected '+ready+'/'+workers.length+(ready<workers.length?' · Reload the game with this mod version.':'');}lastError=null;}catch(error){if(error.message!==lastError){lastError=error.message;status(error.message);}}
    },150);
    window.addEventListener('beforeunload',()=>{window.clearInterval(timer);overlay.remove();},{once:true});
}
