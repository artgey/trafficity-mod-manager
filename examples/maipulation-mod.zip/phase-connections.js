export function connectionsOf(intersection) {
    return Object.fromEntries(intersection.roadEnds.flatMap(end => end.laneEnds).filter(end => end.lanePointLocator.pointIndex > 0).map(end => [end.lanePointLocator.laneSectionId, [...(end.targetLaneSectionIds?.length ? end.targetLaneSectionIds : Object.keys(intersection.crossablePathSet?.[end.lanePointLocator.laneSectionId] || {}).map(Number))]]));
}
export function withConnections(intersection, connections) {
    return { ...intersection, roadEnds: intersection.roadEnds.map(end => ({ ...end, laneEnds: end.laneEnds.map(lane => ({ ...lane, targetLaneSectionIds: lane.lanePointLocator.pointIndex > 0 ? [...(connections[lane.lanePointLocator.laneSectionId] || [])] : [...lane.targetLaneSectionIds] })) })) };
}
export function parallelLanes(intersections) {
    const result = {};
    for (const intersection of Object.values(intersections)) {
        const roadFor = new Map();
        intersection.roadEnds.forEach((end, index) => end.laneEnds.forEach(lane => roadFor.set(lane.lanePointLocator.laneSectionId, index)));
        for (const end of intersection.roadEnds) {
            const lanes = end.laneEnds.filter(lane => lane.lanePointLocator.pointIndex > 0);
            const signature = lane => [...new Set(lane.targetLaneSectionIds.map(id => roadFor.get(id)))].sort().join(',');
            for (const lane of lanes) {
                if (!lane.targetLaneSectionIds.length) continue;
                result[lane.lanePointLocator.laneSectionId] = lanes.filter(peer => signature(peer) === signature(lane)).map(peer => peer.lanePointLocator.laneSectionId);
            }
        }
    }
    return result;
}
export function phaseDiagramNodes(state, intersection, laneWidth, lightOffset) {
    return intersection.roadEnds.flatMap((end, road) => end.laneEnds.flatMap(lane => {
        const locator = lane.lanePointLocator;
        const point = state.saveState.laneSections[locator.laneSectionId]?.points.pointOrUndefined(locator.pointIndex);
        if (!point) return [];
        const source = locator.pointIndex > 0;
        const angle = source ? point.a : point.a + Math.PI;
        const offset = source ? lightOffset : laneWidth / 2;
        return [{ id: locator.laneSectionId, source, road, a: point.a, junctionX: point.x, junctionY: point.y, x: point.x + Math.cos(angle) * offset, y: point.y + Math.sin(angle) * offset }];
    }));
}
let nextDiagramId = 0;
export function phaseConnectionEditor(state, intersection, phase, base, game, onModeChange, onConnectionsChange) {
    const diagramId = 'manipulation-phase-arrow-' + nextDiagramId++;
    const laneWidth = game.getConstants().laneWidth;
    const constants = game.requireRouterModule('bTgKI');
    const curves = game.requireRouterModule('cC9cU');
    const colors = curves.generateSourceLaneColorMap(state, intersection.id);
    const sourceColor = id => '#' + (colors.get(id) ?? 0xffffff).toString(16).padStart(6, '0');
    const host = document.createElement('div');
    const toggleLabel = document.createElement('label');
    const toggle = document.createElement('input'); toggle.type = 'checkbox'; toggle.checked = phase.connections != null;
    toggleLabel.append(toggle, document.createTextNode('Custom connections for this phase'));
    host.appendChild(toggleLabel);
    const content = document.createElement('div'); host.appendChild(content);
    const clone = value => JSON.parse(JSON.stringify(value));
    function draw() {
        content.replaceChildren();
        const hint = document.createElement('p'); hint.className = 'hint';
        hint.textContent = phase.connections ? 'Left-drag from an incoming lane to an outgoing lane. Right-click an origin to remove its connections in this phase.' : 'This phase inherits the general connections.';
        content.appendChild(hint);
        const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
        svg.setAttribute('width','300'); svg.setAttribute('height','260'); svg.style.maxWidth='100%';
        const nodes = phaseDiagramNodes(state, intersection, laneWidth, constants.TRAFFIC_LIGHT_CIRCLE_OFFSET);
        if (!nodes.length) {
            hint.textContent = 'Lane coordinates for this junction are not available yet.';
            return;
        }
        const padding = laneWidth * 4;
        const minX = Math.min(...nodes.map(node=>node.x)) - padding;
        const minY = Math.min(...nodes.map(node=>node.y)) - padding;
        const width = Math.max(laneWidth, Math.max(...nodes.map(node=>node.x)) - minX + padding);
        const height = Math.max(laneWidth, Math.max(...nodes.map(node=>node.y)) - minY + padding);
        svg.setAttribute('viewBox', [minX,minY,width,height].join(' '));
        const roadLayer = document.createElementNS(svg.namespaceURI,'g');
        roadLayer.style.pointerEvents = 'none';
        const junctionEdges = [];
        for (const node of nodes) {
            const perpendicularX = -Math.sin(node.a) * laneWidth / 2;
            const perpendicularY = Math.cos(node.a) * laneWidth / 2;
            const direction = node.source ? -1 : 1;
            const outerX = node.junctionX + Math.cos(node.a) * laneWidth * 3 * direction;
            const outerY = node.junctionY + Math.sin(node.a) * laneWidth * 3 * direction;
            const left = { x: node.junctionX + perpendicularX, y: node.junctionY + perpendicularY };
            const right = { x: node.junctionX - perpendicularX, y: node.junctionY - perpendicularY };
            junctionEdges.push(left,right);
            const road = document.createElementNS(svg.namespaceURI,'polygon');
            road.setAttribute('points', [left, {x:outerX+perpendicularX,y:outerY+perpendicularY}, {x:outerX-perpendicularX,y:outerY-perpendicularY},right].map(point=>point.x+','+point.y).join(' '));
            road.setAttribute('fill','#6b7177'); road.setAttribute('stroke','#d8dde2'); road.setAttribute('stroke-width',laneWidth/14);
            roadLayer.appendChild(road);
            const marking = document.createElementNS(svg.namespaceURI,'path');
            marking.setAttribute('d','M'+node.junctionX+','+node.junctionY+' L'+outerX+','+outerY);
            marking.setAttribute('stroke','#aeb7bf');marking.setAttribute('stroke-width',laneWidth/20);marking.setAttribute('stroke-dasharray',laneWidth/2+' '+laneWidth/3);
            roadLayer.appendChild(marking);
        }
        const centerX = junctionEdges.reduce((sum,point)=>sum+point.x,0)/junctionEdges.length;
        const centerY = junctionEdges.reduce((sum,point)=>sum+point.y,0)/junctionEdges.length;
        junctionEdges.sort((a,b)=>Math.atan2(a.y-centerY,a.x-centerX)-Math.atan2(b.y-centerY,b.x-centerX));
        const crossing = document.createElementNS(svg.namespaceURI,'polygon');
        crossing.setAttribute('points',junctionEdges.map(point=>point.x+','+point.y).join(' '));crossing.setAttribute('fill','#6b7177');
        roadLayer.appendChild(crossing);svg.appendChild(roadLayer);
        const defs = document.createElementNS(svg.namespaceURI,'defs');
        for (const source of nodes.filter(node=>node.source)) {
            const marker = document.createElementNS(svg.namespaceURI,'marker');
            marker.id = diagramId + '-' + source.id;
            for (const [key,value] of Object.entries({viewBox:'0 0 10 10',refX:10,refY:5,markerWidth:5,markerHeight:5,orient:'auto'})) marker.setAttribute(key,value);
            const head = document.createElementNS(svg.namespaceURI,'path');
            head.setAttribute('d','M0,0 L10,5 L0,10 Z');head.setAttribute('fill',sourceColor(source.id));
            marker.appendChild(head);defs.appendChild(marker);
        }
        svg.appendChild(defs);
        const mapping = phase.connections || base;
        function makeArrow(source, points) {
            const line = document.createElementNS(svg.namespaceURI,'path');
            line.setAttribute('d',points.map((point,index)=>(index?'L':'M')+point.x+','+point.y).join(' '));
            line.setAttribute('fill','none');line.setAttribute('stroke',sourceColor(source.id));line.setAttribute('stroke-width',laneWidth/6);
            line.setAttribute('marker-end','url(#'+diagramId+'-'+source.id+')');line.style.pointerEvents='none';
            return line;
        }
        for (const source of nodes.filter(node=>node.source)) {
            for (const targetId of mapping[source.id] || []) {
                const target = nodes.find(node=>!node.source && node.id===targetId);
                if (!target) continue;
                const points = curves.createIntersectionConnectionCurvePointsWithConnectDirectedPoints(source.x,source.y,source.a,target.x,target.y,target.a);
                if (points?.length) svg.appendChild(makeArrow(source,points));
            }
        }
        for (const node of nodes) {
            const group = document.createElementNS(svg.namespaceURI,'g');
            if (node.source) group.dataset.originLaneId=String(node.id);
            const circle = document.createElementNS(svg.namespaceURI,'circle');
            circle.setAttribute('cx',node.x);circle.setAttribute('cy',node.y);circle.setAttribute('r',laneWidth/3);
            circle.setAttribute('fill',node.source?sourceColor(node.id):'none');circle.setAttribute('stroke',node.source?sourceColor(node.id):'#d8dde2');circle.setAttribute('stroke-width',laneWidth/10);
            const hit = document.createElementNS(svg.namespaceURI,'circle');
            hit.setAttribute('cx',node.x);hit.setAttribute('cy',node.y);hit.setAttribute('r',laneWidth/2);hit.setAttribute('fill','transparent');hit.style.pointerEvents='all';
            const label = document.createElementNS(svg.namespaceURI,'text');
            label.setAttribute('x',node.x);label.setAttribute('y',node.y-laneWidth*.7);label.setAttribute('text-anchor','middle');label.setAttribute('fill',node.source?sourceColor(node.id):'#ecf1f8');label.setAttribute('font-size',laneWidth*.5);label.textContent=node.id;
            const title = document.createElementNS(svg.namespaceURI,'title');title.textContent=(node.source?'Zufahrt ':'Ausfahrt ')+node.id;
            group.append(circle,hit,label,title);svg.appendChild(group);
        }
        let drag = null;
        function cancel() {
            if (!drag) return;
            const active=drag;drag=null;active.preview.remove();
            if (svg.hasPointerCapture?.(active.pointerId)) svg.releasePointerCapture(active.pointerId);
        }
        function move(event) {
            if (!drag) return;
            event.preventDefault();event.stopPropagation();
            const matrix=svg.getScreenCTM();if (!matrix) return;
            const cursor=new DOMPoint(event.clientX,event.clientY).matrixTransform(matrix.inverse());
            let target=null,nearest=laneWidth;
            for (const candidate of nodes) {
                if (candidate.source || candidate.road===drag.source.road) continue;
                const distance=Math.hypot(candidate.x-cursor.x,candidate.y-cursor.y);
                if (distance<nearest) { nearest=distance;target=candidate; }
            }
            drag.target=target;
            const source=drag.source;
            const points=target
                ? curves.createIntersectionConnectionCurvePointsWithConnectDirectedPoints(source.x,source.y,source.a,target.x,target.y,target.a)
                : curves.createIntersectionConnectionCurvePointsWithArcToAbsolute(state,source.x,source.y,source.a,cursor.x,cursor.y);
            const visible=points?.length?points:[source,cursor];
            drag.preview.setAttribute('d',visible.map((point,index)=>(index?'L':'M')+point.x+','+point.y).join(' '));
        }
        svg.style.touchAction='none';
        svg.addEventListener('pointerdown',event=>{
            if (event.button!==0 || !phase.connections) return;
            const origin=event.target.closest('[data-origin-lane-id]');if (!origin) return;
            const source=nodes.find(node=>node.source && node.id===Number(origin.dataset.originLaneId));if (!source) return;
            event.preventDefault();event.stopPropagation();cancel();
            const preview=makeArrow(source,[source,source]);preview.dataset.connectionPreview='true';svg.appendChild(preview);
            drag={source,preview,pointerId:event.pointerId,target:null};svg.setPointerCapture(event.pointerId);move(event);
        });
        svg.addEventListener('pointermove',move);
        svg.addEventListener('pointerup',event=>{
            if (event.button!==0 || !drag) return;
            move(event);const {source,target}=drag;cancel();
            if (!target) return;
            const previous=clone(phase.connections);
            const links=phase.connections[source.id]??=[];
            if (!links.includes(target.id)) links.push(target.id);
            if (onConnectionsChange?.()===false) phase.connections=previous;
            draw();
        });
        svg.addEventListener('pointercancel',cancel);
        svg.addEventListener('lostpointercapture',cancel);
        svg.addEventListener('contextmenu',event=>{
            event.preventDefault();event.stopPropagation();
            if (!phase.connections) return;
            const origin=event.target.closest('[data-origin-lane-id]');if (!origin) return;
            cancel();
            const previous=clone(phase.connections);
            phase.connections[Number(origin.dataset.originLaneId)]=[];
            if (onConnectionsChange?.()===false) phase.connections=previous;
            draw();
        });
        content.appendChild(svg);
        const legend=document.createElement('p');legend.className='hint';legend.textContent='Colors match the incoming lanes in the general connection diagram. Numbers are lane IDs. The diagram uses actual lane positions and connection curves. Changes apply immediately.';content.appendChild(legend);
    }
    toggle.addEventListener('change',()=>{
        const previous = phase.connections;
        phase.connections = toggle.checked ? clone(base) : null;
        if (onModeChange?.(toggle.checked) === false) {
            phase.connections = previous;
            toggle.checked = previous != null;
        }
        draw();
    });
    draw();return host;
}
