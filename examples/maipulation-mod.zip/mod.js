import { installRoadTools } from './road-tools.js';
import { categorizeMenu } from './menu-layout.js';
import { installTraffic } from './traffic.js';
import { installStreetNoise } from './street-noise.js';
export default function initializeMod(modApi, game) {
    const id = "maipulation-mod";
    const config = modApi.getConfig(id, { showMenu: false });
    let visible = config.showMenu === true;
    const panel = document.createElement("section");
    panel.className = "manipulation-panel";
    panel.innerHTML = `
      <header><strong>Cheat menu</strong><button data-action="close">×</button></header>
      <p>Alt+M opens or closes this menu.</p>
      <h3>Speed</h3><div data-speeds></div><p data-live></p>
      <h3>Money</h3><input data-money type="number" min="0" max="1000000000000" value="1000000" aria-label="Money amount"><button data-action="money">Set amount</button>
      <h3>Building allowances</h3><select data-building aria-label="Building type"></select>
      <input data-count type="number" min="1" max="100000" value="10" aria-label="Additional building allowances"><button data-action="buildings">Add</button>
      <h3>Map tiles</h3><button data-action="tile">+1 map tile unlock</button><button data-action="tiles">Unlock all map tiles</button>
      <h3>Level</h3><button data-action="level">Unlock next level</button>
      <p class="hint">Money, building allowances, map tiles and levels are stored in the saved game. Additional building allowances may affect level objectives. Actual simulation speed depends on computer performance.</p>
      <p data-status role="status" aria-live="polite"></p>`;
    const trafficHook = { enabled: config.intelligentTraffic === true, workers: new WeakSet() };
    installStreetNoise(modApi, game, config, panel, trafficHook);
    installTraffic(modApi, game, config, panel, trafficHook);
    installRoadTools(modApi,game,config,panel,trafficHook);
    categorizeMenu(panel);
    const find = selector => panel.querySelector(selector);
    let definitions = [];
    let initialized = false;
    function state() {
        const current = globalThis.__trafficityGameState ?? game.getUndoApi()?.gameState;
        if (!current?.saveState || typeof current.requestUiRefresh !== "function") {
            throw new Error("Open a saved game first and move the mouse over the map.");
        }
        return current;
    }
    function moduleWith(moduleId, member) {
        const result = game.requireRouterModule(moduleId);
        if (typeof result?.[member] !== "function") throw new Error("This feature does not support this game version.");
        return result;
    }
    function readNumber(selector, min, max) {
        const text = find(selector).value.trim();
        const value = text === "" ? NaN : Number(text);
        if (!Number.isSafeInteger(value) || value < min || value > max) throw new Error(`Enter a whole number between ${min} and ${max}.`);
        return value;
    }
    function update() {
        if (!visible) return;
        try {
            const current = state();
            const save = current.saveState;
            const paused = save.pauseStateBuffer[0] !== 0;
            find("[data-live]").textContent = `${paused ? "Pause" : current.simSpeed + "×"} · Money ${Number(save.money).toLocaleString("en-US")} · Level ${save.currentDevelopmentPack.number} · Areas ${save.tileUnlockCount}`;
            panel.querySelectorAll("[data-speed]").forEach(button => {
                const selected = paused ? button.dataset.speed === "0" : Number(button.dataset.speed) === current.simSpeed;
                button.setAttribute("aria-pressed", String(selected));
            });
        } catch (error) { find("[data-live]").textContent = error.message; }
    }
    function render() { panel.hidden = !visible; update(); }
    function report(action) {
        try {
            find("[data-status]").textContent = action();
            find("[data-status]").dataset.error = "false";
            update();
        } catch (error) {
            find("[data-status]").textContent = error.message || String(error);
            find("[data-status]").dataset.error = "true";
        }
    }
    for (const speed of [0, 1, 2, 4, 8, 10, 15, 20]) {
        const button = document.createElement("button");
        button.textContent = speed === 0 ? "Pause" : `${speed}×`;
        button.dataset.speed = String(speed);
        button.addEventListener("click", () => report(() => {
            const current = state();
            if (speed === 0) current.saveState.pauseStateBuffer[0] = 1;
            else {
                moduleWith("4rdeQ", "setSimSpeed").setSimSpeed(current, speed);
                current.saveState.pauseStateBuffer[0] = 0;
            }
            current.requestUiRefresh();
            return speed === 0 ? "Paused." : `${speed}× enabled.`;
        }));
        find("[data-speeds]").appendChild(button);
    }
    const actions = {
        money() {
            const value = readNumber("[data-money]", 0, 1000000000000);
            const current = state();
            current.saveState.money = value;
            current.requestUiRefresh();
            return `Money set to ${value.toLocaleString("en-US")}.`;
        },
        buildings() {
            const count = readNumber("[data-count]", 1, 100000);
            const selected = find("[data-building]").value;
            const targets = selected === "*" ? definitions : definitions.filter(item => item.type === selected);
            if (!targets.length) throw new Error("No building types available.");
            const current = state();
            const counts = { ...current.saveState.cumulativeBuildingCount };
            for (const item of targets) {
                const next = (counts[item.type] ?? 0) + count;
                if (!Number.isSafeInteger(next)) throw new Error("Building allowance is too large.");
                counts[item.type] = next;
            }
            current.saveState.cumulativeBuildingCount = counts;
            current.requestUiRefresh();
            return `Added ${count} building allowances for each of ${targets.length} building types.`;
        },
        tile() {
            const current = state();
            current.saveState.tileUnlockCount += 1;
            current.requestUiRefresh();
            return "+1 map tile unlock available. Select the tile using the normal build menu.";
        },
        tiles() {
            moduleWith("fUKGN", "unlockAllTiles").unlockAllTiles(state());
            return "All map tiles unlocked.";
        },
        level() {
            const current = state();
            const progression = moduleWith("aigC5", "claimPendingDevelopmentPackUnlock");
            if (typeof progression.getPendingDevelopmentPack !== "function" || !current.trafficFlow) throw new Error("Level progression is not available for this saved game.");
            const save = current.saveState;
            const previous = save.pendingDevelopmentPackNumber;
            save.pendingDevelopmentPackNumber = save.currentDevelopmentPack.number + 1;
            try {
                if (!progression.getPendingDevelopmentPack(save)) throw new Error("No further level available.");
            } catch (error) {
                save.pendingDevelopmentPackNumber = previous;
                throw error;
            }
            progression.claimPendingDevelopmentPackUnlock(save, current.trafficFlow);
            current.requestUiRefresh();
            return `Unlocked level ${save.currentDevelopmentPack.number} with its normal rewards.`;
        }
    };
    panel.addEventListener("click", event => {
        const button = event.target.closest("button[data-action]");
        if (!button) return;
        if (button.dataset.action === "close") { visible = false; render(); return; }
        const action = actions[button.dataset.action];
        if (action) report(action);
    });
    for (const type of ["keydown", "keyup"]) panel.addEventListener(type, event => { if (event.key !== 'Escape') event.stopPropagation(); });
    game.on("ready", () => {
        if (initialized) return;
        initialized = true;
        try {
            const buildings = game.requireRouterModule("4nkf2");
            if (!Array.isArray(buildings?.BUILDING_DEFINITIONS)) throw new Error("The building list is not available for this game version.");
            definitions = buildings.BUILDING_DEFINITIONS;
            for (const item of [{ type: "*", name: "All building types" }, ...definitions]) {
                const option = document.createElement("option");
                option.value = item.type;
                option.textContent = item.name || item.type;
                find("[data-building]").appendChild(option);
            }
        } catch (error) { find("[data-status]").textContent = error.message; }
        modApi.addOverlay(id, panel);
        render();
        const timer = window.setInterval(update, 500);
        window.addEventListener("beforeunload", () => window.clearInterval(timer), { once: true });
    });
    modApi.bindKey("Alt+m", () => { visible = !visible; render(); });
}
