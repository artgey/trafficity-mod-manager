export function trafficEnabled() {
    return globalThis.__manipulationControl ? Atomics.load(globalThis.__manipulationControl,1)===1 : globalThis.__intelligentTraffic===true;
}

export function laneLoads(network, cars, time) {
    const cache=globalThis.__trafficLoadCache;
    const bucket=Math.floor(time*2);
    if (cache?.roads===network.laneSections && cache.cars===cars && cache.bucket===bucket) return cache.loads;
    const loads=new Map();
    const maximum=cars?.getMaxResidentId?.() || 0;
    for(let id=1;id<=maximum;id++) {
        if(!cars.getExists(id) || cars.getParkedInGarageBuildingId(id)!=null || cars.getParkedInParkingSpaceLocator(id)!=null) continue;
        const laneId=cars.getCurrentLaneSectionId(id),lane=network.laneSections[laneId];
        if(!lane?.points?.length) continue;
        const point=cars.getCurrentLanePointIndex(id);
        if(point<0 || point>=lane.points.length) continue;
        let load=loads.get(laneId);
        if(!load) { load={count:0,queued:0};loads.set(laneId,load); }
        load.count++;
        if(cars.getSpeed(id)<=Math.max(1,cars.getMaxSpeed(id)*0.2)) load.queued++;
    }
    globalThis.__trafficLoadCache={roads:network.laneSections,cars,bucket,loads};
    return loads;
}

export function laneChangesBetween(network, start, end) {
    if(!start || !end) return 0;
    const pending=[{id:start.laneSectionId,changes:0}],best=new Map();
    for(let visited=0;pending.length && visited<256;visited++) {
        const current=pending.shift();
        if(best.has(current.id) && best.get(current.id)<=current.changes) continue;
        best.set(current.id,current.changes);
        if(current.id===end.laneSectionId) return current.changes;
        const lane=network.laneSections[current.id];
        if(!lane) continue;
        if(lane.continuesTo!=null) pending.unshift({id:lane.continuesTo,changes:current.changes});
        for(const id of [lane.leftGluedLaneSectionId,lane.rightGluedLaneSectionId]) {
            if(id!=null) pending.push({id,changes:current.changes+1});
        }
    }
    return 0;
}

export function routingCost(network, previous, follow, arrive, connection) {
    const tools=globalThis.__roadPlanningRules??globalThis.__roadRules;
    if(tools?.enabled && !globalThis.__roadTransitionAllowed(network,previous,follow,arrive,connection)) return Infinity;
    if(!globalThis.__trafficEnabled()) return 0;
    const cars=globalThis.__trafficCars;
    const time=globalThis.__trafficClock?.[0] || 0;
    const loads=globalThis.__laneLoads(network,cars,time);
    const starts=previous.lanePointLocators || [];
    const changes=starts.length?Math.min(...starts.map(start=>globalThis.__laneChangesBetween(network,start,follow))):0;
    let cost=changes*2.2;
    // Full-route search includes this cost at every next junction, so selecting
    // an exit lane also accounts for the lane needed at the following turn.
    if(connection.type==='use intersection') {
        const incoming=loads.get(connection.sourceLaneId) || {count:0,queued:0};
        const outgoing=loads.get(connection.targetLaneId) || {count:0,queued:0};
        cost+=incoming.queued*1.8+incoming.count*0.12+outgoing.queued*0.8;
        const resident=globalThis.__trafficPlanningResident || 0;
        let hash=Math.imul(resident+1,0x9e3779b1)^Math.imul(connection.sourceLaneId+1,0x85ebca6b)^Math.imul(connection.targetLaneId+1,0xc2b2ae35);
        hash^=hash>>>16;
        cost+=((hash>>>0)/4294967296)*0.9;
    }
    const stats=globalThis.__trafficStats ??= {checks:0,changes:0,heldAtSignal:0};
    stats.routeEvaluations=(stats.routeEvaluations || 0)+1;
    return cost;
}

export function installPlannerSource(source) {
    const needle='K=(e,t,n,i,r)=>{let o=w+r,a=y[i];';
    if(source.split(needle).length!==2) throw new Error('Destination-aware lane planning: unsupported game version.');
    const destination='ea=(e,t,n,i,r,o)=>{let l=e.buildings[n];';
    if(source.split(destination).length!==2)throw new Error('Service access: unsupported destination planner.');
    source=source.replace(destination,'ea=(e,t,n,i,r,o)=>{globalThis.__roadPlanningDestination=n;let l=e.buildings[n];');
    let patched=source.replace(needle,'K=(e,t,n,i,r)=>{r+=globalThis.__routingCost(f,m,e,t,n);if(!Number.isFinite(r))return;let o=w+r,a=y[i];');
    const request='let n=y[0];if((0,I.setRoutePenaltySeed)';
    if(patched.includes(request)) patched=patched.replace(request,'globalThis.__trafficPlanningResident=t.residentId;globalThis.__roadPlanningRules=t.roadRuleSnapshot||null;globalThis.__roadPlanningAccess=t.roadAccess||null;globalThis.__roadPlanningCompleted=t.ignoredRoadSignKeys||{};let n=y[0];if((0,I.setRoutePenaltySeed)');
    const functions={__trafficEnabled:trafficEnabled,__laneLoads:laneLoads,__laneChangesBetween:laneChangesBetween,__routingCost:routingCost};
    const prefix=Object.entries(functions).map(([name,fn])=>'globalThis.'+name+'='+fn.toString()+';').join('');
    return prefix+`self.addEventListener('message',function(event){const data=event.data;if(data?.carMetadataBuffers){globalThis.__trafficCars=new(globalThis.parcelRequireeccb('4zSMG').ParallelResidentMetadata)(data.carMetadataBuffers);}if(data?.gameTimeBuffer)globalThis.__trafficClock=new Float32Array(data.gameTimeBuffer);if(data?.type==='maipulation-signal-routing'){globalThis.__phaseRouting=data.plans;globalThis.__phaseRoutingEnabled=data.enabled;globalThis.__parallelSignalLanes=data.parallel;event.stopImmediatePropagation();}},true);\n`+patched;
}
