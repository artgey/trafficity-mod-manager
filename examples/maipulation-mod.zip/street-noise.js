import { installPlannerSource } from './traffic-planner.js';
import { installRoadRuleSource } from './road-rules.js';
import { patchTrafficWorker } from './traffic-core.js';

export function patchNoiseWorker(source) {
    const derived = 'getDrivedATMapPoint(e,t,n,i){return o(this.getUnderlyingPollutionAtMapPoint(e,t),n,i)}';
    const cell = 'getValueAtCellIndex(e){return this.values[e]}';
    const map = 'this.isCellInBounds(n,i)?this.values[this.getCellIndex(n,i)]:0';
    for (const needle of [derived, cell, map]) {
        if (source.split(needle).length !== 2) throw new Error('Road noise calculation does not support this game version.');
    }
    return source
        .replace(derived, 'getDrivedATMapPoint(e,t,n,i){return o(this.getUnderlyingPollutionAtMapPoint(e,t),n,i)*(this.pollutionValues.buffer===globalThis.__roadNoiseBuffer?globalThis.__noiseFactor():1)}')
        .replace(cell, 'getValueAtCellIndex(e){return this.values[e]*(globalThis.__ambientNoiseBuffers?.has(this.values.buffer)?globalThis.__noiseFactor():1)}')
        .replace(map, 'this.isCellInBounds(n,i)?this.values[this.getCellIndex(n,i)]*(globalThis.__ambientNoiseBuffers?.has(this.values.buffer)?globalThis.__noiseFactor():1):0');
}

export function installStreetNoise(modApi, game, config, panel, runtime) {
    const allowed = [1, 0.75, 0.65, 0.5];
    let factor = allowed.includes(Number(config.streetNoiseFactor)) ? Number(config.streetNoiseFactor) : 1;
    const control = new Int32Array(new SharedArrayBuffer(4 * Int32Array.BYTES_PER_ELEMENT));
    Atomics.store(control, 0, Math.round(factor * 100));
    Atomics.store(control, 1, config.intelligentTraffic === true ? 1 : 0);
    Atomics.store(control, 2, config.modernTrafficLights === true ? 1 : 0);
    Atomics.store(control,3,config.roadToolsEnabled===true?1:0);
    let mergeBuffer=new SharedArrayBuffer((1+32768*6)*Int32Array.BYTES_PER_ELEMENT);
    const mergeReceivers=new Set();
    runtime.control = control;
    runtime.info = new Map();
    runtime.errors = [];
    runtime.stats = { checks: 0, changes: 0, heldAtSignal: 0 };
    const NativeWorker = window.Worker;
    function PatchedGameWorker(scriptURL, options) {
        const kind = String(scriptURL).match(/(car|happiness|pathfinding)-worker/)?.[1];
        if (!kind || options?.type) return new NativeWorker(scriptURL, options);
        let url;
        try {
            const request = new XMLHttpRequest();
            request.open('GET', String(scriptURL), false);
            request.send();
            if (request.status !== 0 && (request.status < 200 || request.status >= 300)) throw new Error('Could not read the worker source.');
            let source = patchNoiseWorker(request.responseText);
            if (kind === 'car') source = patchTrafficWorker(source, runtime.enabled);
            if(kind==='car'||kind==='pathfinding') source=installRoadRuleSource(installPlannerSource(source));
            const prefix = `globalThis.__noiseFactor=()=>globalThis.__manipulationControl?Atomics.load(globalThis.__manipulationControl,0)/100:1;globalThis.__ambientNoiseBuffers=new Set();self.addEventListener('message',function(event){const data=event.data;if(data?.__manipulationControl){globalThis.__manipulationControl=new Int32Array(data.__manipulationControl);if(data.carNoiseGridBuffers){globalThis.__roadNoiseBuffer=data.carNoiseGridBuffers.pollutionValuesBuffer;globalThis.__ambientNoiseBuffers=new Set([data.streetNoiseGridBuffers?.valuesBuffer,data.highwayNoiseGridBuffers?.valuesBuffer,data.trafficJamNoiseGridBuffers?.valuesBuffer]);}self.postMessage({type:'maipulation-runtime-ready',kind:'${kind}'});}if(data?.type==='maipulation-runtime-stats'){self.postMessage({type:'maipulation-runtime-stats',stats:globalThis.__trafficStats||{}});event.stopImmediatePropagation();}},true);\n`;
            url = URL.createObjectURL(new Blob([prefix, source], { type: 'application/javascript' }));
            const worker = new NativeWorker(url + '#' + kind + '-worker', options);
            runtime.workers.add(worker);
            runtime.info.set(worker, { kind, ready: false, stats: {} });
            const originalPost = worker.postMessage.bind(worker);
            if(kind==='car'){
                mergeReceivers.add(originalPost);
                const terminate=worker.terminate?.bind(worker);
                if(terminate)worker.terminate=()=>{mergeReceivers.delete(originalPost);return terminate();};
            }
            let controlSent = false;
            worker.postMessage = (data, transfer) => {
                const capacity=data?.carMetadataBuffers?.existsBuffer?.byteLength;
                if(kind==='car'&&capacity&&(1+capacity*6)*Int32Array.BYTES_PER_ELEMENT>mergeBuffer.byteLength){
                    // Every resident ID needs a reservation slot, including
                    // cities exceeding the old 32,768-resident allocation.
                    const next=new SharedArrayBuffer((1+capacity*6)*Int32Array.BYTES_PER_ELEMENT);
                    new Int32Array(next).set(new Int32Array(mergeBuffer));Atomics.store(new Int32Array(next),0,0);mergeBuffer=next;
                    for(const send of mergeReceivers)send({__trafficMergeBuffer:mergeBuffer});
                }
                const needsControl = !controlSent || data?.carNoiseGridBuffers;
                const payload = needsControl && data && typeof data === 'object' ? { ...data, __manipulationControl: control.buffer, ...(kind==='car'?{__trafficMergeBuffer:mergeBuffer}:{}) } : data;
                if (needsControl) controlSent = true;
                return transfer === undefined ? originalPost(payload) : originalPost(payload, transfer);
            };
            worker.addEventListener('message', event => {
                if (event.data?.type === 'maipulation-runtime-ready') {
                    runtime.info.get(worker).ready = true;
                    URL.revokeObjectURL(url);
                    event.stopImmediatePropagation();
                } else if (event.data?.type === 'maipulation-runtime-stats') {
                    runtime.info.get(worker).stats = event.data.stats;
                    event.stopImmediatePropagation();
                }
            }, true);
            worker.addEventListener('error', event => {
                runtime.errors.push(kind + ': ' + event.message);
                URL.revokeObjectURL(url);
            }, { once: true });
            return worker;
        } catch (error) {
            if (url) URL.revokeObjectURL(url);
            runtime.errors.push(kind + ': ' + error.message);
            console.error('[maipulation-mod] Could not extend worker:', error);
            return new NativeWorker(scriptURL, options);
        }
    }
    PatchedGameWorker.prototype = NativeWorker.prototype;
    Object.setPrototypeOf(PatchedGameWorker, NativeWorker);
    window.Worker = PatchedGameWorker;

    const section = document.createElement('section');
    section.innerHTML = '<h3>Street modification</h3><p class="hint">Quiet asphalt reduces road noise in the overlay and building satisfaction calculations. Standard restores the original exposure.</p><div data-noise-buttons></div><p data-noise-status role="status"></p><p data-noise-measure class="hint"></p>';
    panel.insertBefore(section, panel.querySelector('[data-status]'));
    const status = section.querySelector('[data-noise-status]');
    const buttons = [];
    const wrappedGrids = new WeakSet();
    const wrappedContexts = new WeakSet();
    function current() { return globalThis.__trafficityGameState ?? game.getUndoApi()?.gameState; }
    function installGridHooks(state) {
        const grid = state?.saveState?.carNoiseGrid;
        if (!grid) return;
        // Only scale the derived exposure. Raw values are also used by diffusion
        // and decay and must never be changed by display or happiness reads.
        if (!wrappedGrids.has(grid)) {
            const original = grid.getDrivedATMapPoint.bind(grid);
            grid.getDrivedATMapPoint = (...args) => original(...args) * factor;
            wrappedGrids.add(grid);
            for (const name of ['streetNoiseGrid', 'highwayNoiseGrid', 'trafficJamNoiseGrid']) {
                const ambient = state.saveState[name];
                if (!ambient) continue;
                for (const method of ['getValueAtCellIndex', 'getValueAtMapPoint']) {
                    const read = ambient[method].bind(ambient);
                    ambient[method] = (...args) => read(...args) * factor;
                }
            }
        }
        const context = state.carNoiseOverlayBitmap?.context;
        if (!context || wrappedContexts.has(context)) return;
        const originalPut = context.putImageData.bind(context);
        context.putImageData = (image, ...args) => {
            if (factor === 1) return originalPut(image, ...args);
            const alphas = new Uint8Array(image.data.length / 4);
            for (let index = 0; index < alphas.length; index++) {
                const alphaIndex = index * 4 + 3;
                alphas[index] = image.data[alphaIndex];
                image.data[alphaIndex] = Math.round(alphas[index] * factor);
            }
            try { return originalPut(image, ...args); }
            finally {
                for (let index = 0; index < alphas.length; index++) image.data[index * 4 + 3] = alphas[index];
            }
        };
        wrappedContexts.add(context);
    }
    function redrawOverlay(state) {
        const bitmap = state?.carNoiseOverlayBitmap;
        const grid = state?.saveState?.carNoiseGrid;
        if (!bitmap || !grid) return;
        const rendering = game.requireRouterModule('7VBKL').carNoiseOverlayRenderConfig;
        const data = bitmap.imageData.data;
        for (let index = 0; index < grid.pollutionValues.length; index++) {
            const raw = grid.pollutionValues[index];
            const derived = Math.max(0, Math.min(1, (raw - rendering.derivedStartCutoff) / (rendering.derivedFullCutoff - rendering.derivedStartCutoff)));
            data[index * 4 + 3] = Math.round(derived * rendering.maxOpacity * 255);
        }
        bitmap.context.putImageData(bitmap.imageData, 0, 0);
        bitmap.sprite.texture.source.update();
    }
    function refresh() {
        for (const button of buttons) button.setAttribute('aria-pressed', String(Number(button.dataset.factor) === factor));
        try {
            const state = current();
            installGridHooks(state);
            const grid = state?.saveState?.carNoiseGrid;
            if (!grid) return;
            let before = 0;
            let after = 0;
            const rendering = game.requireRouterModule('7VBKL').carNoiseOverlayRenderConfig;
            for (let index = 0; index < grid.pollutionValues.length; index++) {
                const raw = grid.pollutionValues[index];
                const derived = Math.max(0, Math.min(1, (raw - rendering.derivedStartCutoff) / (rendering.derivedFullCutoff - rendering.derivedStartCutoff)));
                before += derived;
                after += derived * factor;
            }
            section.querySelector('[data-noise-measure]').textContent = `Road noise grid: ${(before / grid.pollutionValues.length * 100).toFixed(2)}% Standard → ${(after / grid.pollutionValues.length * 100).toFixed(2)}% effective. Building indicators adjust gradually.`;
        } catch (error) { status.textContent = error.message; }
    }
    for (const [value, label] of [[1, 'Standard noise'], [0.75, 'Reduce noise by 25%'], [0.65, 'Reduce noise by 35%'], [0.5, 'Reduce noise by 50%']]) {
        const button = document.createElement('button');
        button.textContent = label;
        button.dataset.factor = String(value);
        button.addEventListener('click', async () => {
            try {
                const state = current();
                installGridHooks(state);
                factor = value;
                Atomics.store(control, 0, Math.round(value * 100));
                state?.requestUiRefresh();
                redrawOverlay(state);
                refresh();
                const workers = [...(state?.carWorkers || []), ...(state?.happinessWorkers || [])];
                const missing = workers.filter(worker => !runtime.info.get(worker)?.ready).length;
                status.textContent = label + ' enabled for road noise.' + (missing ? ' For building satisfaction, reload the game with this mod version (' + missing + ' workers not connected yet).' : '');
                await modApi.setConfig('maipulation-mod', { ...modApi.getConfig('maipulation-mod', {}), streetNoiseFactor: value });
            } catch (error) { status.textContent = error.message; }
        });
        buttons.push(button);
        section.querySelector('[data-noise-buttons]').appendChild(button);
    }
    game.on('ready', refresh);
    const timer = window.setInterval(() => { if (!panel.hidden) refresh(); else { try { installGridHooks(current()); } catch (error) { status.textContent = error.message; } } }, 1000);
    window.addEventListener('beforeunload', () => window.clearInterval(timer), { once: true });
    refresh();
}
