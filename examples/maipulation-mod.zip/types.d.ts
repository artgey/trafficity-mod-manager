export {};

declare global {
    interface TrafficityServices {
        // Register typed services if you call mods.provide("maipulation-mod", ...)
    }
}
