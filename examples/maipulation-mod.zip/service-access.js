export function serviceFacilityIds(sign,network) {
    return (sign.allowedBuildingIds||[]).filter(id=>network.buildings?.[id]?.footprint?.validity==='valid');
}

export function serviceWorkplace(network,id) {
    const building=network.buildings?.[id];if(!building)return false;
    if(globalThis.parcelRequireeccb){
        const definition=globalThis.parcelRequireeccb('aS4Aq').getBuildingDefinition(building.type);
        return definition.buildingCategory==='industrial'||definition.buildingCategory==='office';
    }
    return /industrial|office/.test(building.type);
}

export function serviceAccessAllowed(sign,network,access,destination) {
    const allowed=serviceFacilityIds(sign,network);
    // A newly placed or orphaned sign stays inactive until facilities are linked.
    if(!allowed.length)return true;
    if(!access)return false;
    const goal=destination??access.destination;
    const delivery=access.kind===3;
    const work=access.kind===1||access.kind===2&&serviceWorkplace(network,goal);
    if(delivery)return [goal,access.home,access.visit,access.origin].some(id=>allowed.includes(id));
    if(!work&&!(access.kind===2&&access.returning&&[access.visit,access.origin].some(id=>allowed.includes(id)&&serviceWorkplace(network,id))))return false;
    if(allowed.includes(goal))return true;
    return access.returning===true&&[access.visit,access.origin].some(id=>allowed.includes(id));
}

export function serviceAccessContext(car,start,destination) {
    const plan=car.carPlan||[],step=plan[0];
    const kind=car.pathfindingWait?.journeyType??car.journeyTrace?.journeyType??-1;
    const picking=car.pathfindingWait?.kind==='pickDest';
    if(picking)car.roadAccessVisitBuildingId=null;
    const outgoing=picking?null:plan.find(item=>item.type==='travel to location')?.destinationBuildingId;
    let origin=null;
    const metadata=globalThis.__trafficCars;
    const garage=metadata?.getParkedInGarageBuildingId?.(car.residentId);
    if(garage!=null)origin=garage;
    let parking=start?.type==='parking space'?start.locator:null;
    parking??=metadata?.getParkedInParkingSpaceLocator?.(car.residentId);
    if(parking==null)parking=plan.find(item=>item.type==='wait at location')?.parkingSpaceLocator;
    if(parking!=null&&globalThis.parcelRequireeccb)origin=globalThis.parcelRequireeccb('2dJqa').getBuildingIdFromParkingSpaceLocator(parking);
    if(start?.type==='parking garage exit')origin=start.buildingId;
    const returning=step?.type==='travel home'||car.pathfindingWait?.purpose==='travelHome';
    if(outgoing!=null&&kind>=0)car.roadAccessVisitBuildingId=outgoing;
    else if(returning&&origin!=null&&origin!==car.homeBuildingId)car.roadAccessVisitBuildingId=origin;
    return {kind,home:car.homeBuildingId,visit:car.roadAccessVisitBuildingId??null,origin,destination:destination??outgoing??null,returning};
}

export function installServiceAccessSource(source) {
    const functions=[serviceFacilityIds,serviceWorkplace,serviceAccessAllowed,serviceAccessContext];
    return '(function(){'+functions.map(fn=>fn.toString()).join('\n')+';Object.assign(globalThis,{__serviceAccessAllowed:serviceAccessAllowed,__roadAccessContext:serviceAccessContext});})();\n'+source;
}

export function facilityAtPoint(buildings,x,y) {
    let match=null,best=Infinity;
    for(const building of Object.values(buildings||{})){
        const p=building.footprint;if(p?.validity!=='valid')continue;
        const dx=x-p.centerX,dy=y-p.centerY,a=p.rotation||0,c=Math.cos(a),s=Math.sin(a);
        const localX=dx*c+dy*s,localY=-dx*s+dy*c;
        if(Math.abs(localX)<=(p.width||0)/2+3&&Math.abs(localY)<=(p.depth||0)/2+3){
            const distance=dx*dx+dy*dy;if(distance<best){match=building;best=distance;}
        }
    }
    return match;
}

export function facilityLabel(building,game) {
    const definitions=game.requireRouterModule('4nkf2')?.BUILDING_DEFINITIONS||[];
    return definitions.find(d=>d.type===building.type)?.name||building.type.split('-').map(word=>word.charAt(0).toUpperCase()+word.slice(1)).join(' ');
}

export function facilityCorners(footprint) {
    const c=Math.cos(footprint.rotation||0),s=Math.sin(footprint.rotation||0),w=footprint.width/2,d=footprint.depth/2;
    return [[-w,-d],[w,-d],[w,d],[-w,d]].map(([x,y])=>({x:footprint.centerX+x*c-y*s,y:footprint.centerY+x*s+y*c}));
}

