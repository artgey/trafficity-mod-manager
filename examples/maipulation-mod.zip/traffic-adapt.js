export function maybeReplanTraffic(car,network,cars,time,pathfinding,manager) {
    const rules=globalThis.__roadRules;
    if(rules&&car.__roadRuleVersion!==rules){
        if(globalThis.__roadRouteAffected?.(car,network,globalThis.__roadRuleChangedSigns||[]))car.__roadRulesDirty=true;
        car.__roadRuleVersion=rules;
    }
    const urgent=car.__roadRulesDirty===true;
    const retry=car.__trafficAnchorRetry;
    if(retry&&manager){
        if(time<retry.time)return true;
        const point=network.laneSections[retry.locator.laneSectionId]?.points.pointOrUndefined(retry.locator.pointIndex);
        if(!point){car.__trafficAnchorRetry=null;return false;}
        if(!manager.canAcquireHardLockAtPose(point.x,point.y,point.a,point.elevation??0,car.residentId)){retry.time=time+.5;return true;}
        const outcome=manager.resetPathAndExtendAfterRouteFix(car.residentId,retry.locator,()=>{},false);
        if(outcome===retry.none){car.__trafficAnchorRetry=null;car.periodicCheckCountdown=0;}else retry.time=time+.5;
        return true;
    }
    const intelligent=globalThis.__trafficEnabled?.();
    const tools=globalThis.__roadToolsEnabled?.();
    if((!intelligent&&!tools&&!urgent)||car.pathfindingWait||!car.path?.length||!car.route?.length)return false;
    if(!urgent&&(time<(car.__trafficCheckAt||0)||time<(car.__trafficReplanAt||0)))return false;
    car.__trafficCheckAt=time+.75+(car.residentId%13)*.03;
    const head=car.path.get(0),laneId=head.equivalentLanePointLaneSectionId,index=head.equivalentLanePointPointIndex;
    const lane=network.laneSections[laneId];
    if(!lane||index==null||head.parkingArcPointsRemaining!=null||head.isParkingPath||head.switchingLaneFromLaneSectionId!=null||car.cleanswitchLockId!=null||car.pushInLockId!=null)return false;
    const end=car.route.slice().reverse().find(node=>['enter parking space','enter parking garage'].includes(node.connectionIntoThisNode?.type))?.connectionIntoThisNode.buildingId??car.reroute?.endBuildingId;
    if(end==null)return false;
    let required=urgent;
    if(tools) {
        globalThis.__roadMoveLimit(car,network,cars,time);
        required=required||car.__roadNeedsReplan===true;
    }
    if(!required) {
        // Ordinary queue balancing stays local. Native planJourney suspends
        // the requesting vehicle, so speculative searches can stop whole
        // queues when a large city's pathfinding workers are busy.
        return false;
    }
    // Up to eight rule-driven requests per simulated second in each partition.
    // The ordinary destination search and all collision/lock checks stay native.
    const bucket=Math.floor(time*(required?8:2));
    if(!urgent&&globalThis.__trafficReplanBucket===bucket)return false;
    globalThis.__trafficReplanBucket=bucket;
    const locator={laneSectionId:laneId,pointIndex:index};
    if(required&&car.reroute){if(!pathfinding.clearReroute)return false;pathfinding.clearReroute(car);}
    car.__trafficRequestRoadRules=rules;
    pathfinding.requestPlanJourney(car,{type:'lane point',locator},end,'mod-traffic',{currentLanePointLocator:locator});
    if(!car.pathfindingWait)return false;
    car.__roadRulesDirty=false;
    car.__trafficReplanAt=time+(required?5:25);
    const stats=globalThis.__trafficStats??={};stats.replans=(stats.replans||0)+1;if(urgent)stats.immediateReplans=(stats.immediateReplans||0)+1;
    return true;
}

export function replanAffectedCars(partition,network,cars,time,pathfinding,manager) {
    let requested=0;
    for(const car of partition)if(globalThis.__roadRouteAffected(car,network,globalThis.__roadRuleChangedSigns||[])){
        car.__roadRulesDirty=true;car.periodicCheckCountdown=0;
        if(globalThis.__maybeReplanTraffic(car,network,cars,time,pathfinding,manager))requested++;
    }
    return requested;
}

export function patchAdaptiveTraffic(source) {
    const periodic='if(eA.markWaitForCycleHeadAwaitingPathfinding(e,i,e_[0]),i)continue;';
    const result='td=e=>{let t=eu[e.residentId];if(!t)return;';
    for(const needle of [periodic,result])if(source.split(needle).length!==2)throw new Error('Adaptive routes: unsupported game version.');
    const registration="self.addEventListener(\"message\",e=>{let t=e.data;if(\"frame\"===t)return void th();";
    if(source.split(registration).length!==2)throw new Error('Immediate rerouting: unsupported worker version.');
    source=source.replace(registration,"globalThis.__onRoadRulesChanged=()=>{if(!eA||!e_||!eT||!globalThis.__roadRoutingPortsReady)return;globalThis.__replanAffectedCars(eg,ec,eA,e_[0],Z,eT);};"+registration);
    source=source.replace("(0,Z.bindPathfindingPorts)(t)",'((0,Z.bindPathfindingPorts)(t),globalThis.__roadRoutingPortsReady=true)');
    const request='p(e,{type:"planJourney",requestId:s,residentId:e.residentId,worldGeneration:o,startLocator:t,endBuildingId:n})';
    if(source.split(request).length!==2)throw new Error('Merge completion tracking: unsupported game version.');
    source=source.replace(request,'p(e,{type:"planJourney",requestId:s,residentId:e.residentId,worldGeneration:o,startLocator:t,endBuildingId:n,roadRuleSnapshot:globalThis.__roadRules,roadAccess:globalThis.__roadAccessContext(e,t,n),ignoredRoadSignKeys:t.type==="lane point"?(e.__roadCompletedMerges||{}):{}})');
    const pick='parkedLocator:i.parkedLocator,nearbyKind:i.nearbyKind})';
    if(source.split(pick).length!==2)throw new Error('Service access: unsupported destination request.');
    source=source.replace(pick,'parkedLocator:i.parkedLocator,nearbyKind:i.nearbyKind,roadRuleSnapshot:globalThis.__roadRules,roadAccess:globalThis.__roadAccessContext(e)})');
    const reroute='startLocator:{type:"lane point",locator:t},endBuildingId:n})';
    if(source.split(reroute).length!==2)throw new Error('Service access: unsupported reroute request.');
    source=source.replace(reroute,'startLocator:{type:"lane point",locator:t},endBuildingId:n,roadRuleSnapshot:globalThis.__roadRules,roadAccess:globalThis.__roadAccessContext(e,{type:"lane point",locator:t},n)})');
    source=source.replaceAll('carPlan:e.carPlan,homeBuildingId:e.homeBuildingId,','carPlan:e.carPlan,homeBuildingId:e.homeBuildingId,roadAccessVisitBuildingId:e.roadAccessVisitBuildingId??null,');
    source=source.replace('carPlan:t.carPlan,homeBuildingId:t.homeBuildingId,','carPlan:t.carPlan,homeBuildingId:t.homeBuildingId,roadAccessVisitBuildingId:t.roadAccessVisitBuildingId??null,');
    return 'globalThis.__replanAffectedCars='+replanAffectedCars.toString()+';globalThis.__maybeReplanTraffic='+maybeReplanTraffic.toString()+';\n'+source
        .replace(periodic,'if(eA.markWaitForCycleHeadAwaitingPathfinding(e,i,e_[0]),i||globalThis.__maybeReplanTraffic(n,ec,eA,e_[0],Z,eT))continue;')
        .replace(result,result+'if(t.pathfindingWait?.purpose==="mod-traffic"&&t.pathfindingWait.requestId===e.requestId){const stats=globalThis.__trafficStats??={};if(t.__trafficRequestRoadRules!==globalThis.__roadRules&&(t.__roadRulesDirty||globalThis.__roadRouteAffected({...t,route:e.result?.route||t.route},ec,globalThis.__roadRuleChanges(t.__trafficRequestRoadRules,globalThis.__roadRules)))){(0,Z.clearPathfindingWait)(t);t.__roadRulesDirty=true;stats.staleRuleResults=(stats.staleRuleResults||0)+1;globalThis.__maybeReplanTraffic(t,ec,eA,e_[0],Z,eT);return;}if(e.result&&(0,Z.getPathfindingWorldGeneration)()===t.pathfindingWait.worldGeneration){const locator=t.pathfindingWait.currentLanePointLocator;eT.resetLaneSwitchStateForNewRouteHead(t);t.periodicCheckCountdown=0;t.periodicCheckLastSnapshot=undefined;t.pathingSnooze=0;const outcome=eT.applyRepairPlanResult(t.residentId,e.result);if(outcome===N.TeleportHomeReason.NONE){stats.replansApplied=(stats.replansApplied||0)+1;t.__trafficAnchorRetry=null;}else{stats.replanFailures=(stats.replanFailures||0)+1;t.__trafficAnchorRetry={locator,time:e_[0]+.25,none:N.TeleportHomeReason.NONE};}}else{(0,Z.clearPathfindingWait)(t);stats.noLegalRoute=(stats.noLegalRoute||0)+1;}return;}');
}
