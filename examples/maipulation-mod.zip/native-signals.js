import { connectionsOf, withConnections } from './phase-connections.js';

export function installNativeSignals(game, controller) {
    const React = game.requireRouterModule('acw62');
    const jsx = game.requireRouterModule('ayMG0');
    const diagrams = game.requireRouterModule('cJPTI');
    const NativeDiagram = diagrams?.IntersectionSVG;
    if (!React?.useState || !jsx?.jsx || !NativeDiagram) throw new Error('Could not extend the original traffic light editor.');
    const listeners = new Set();
    controller.redrawNative = () => { for (const listener of listeners) listener(); };
    function NativeSignalDiagram(props) {
        const [, render] = React.useState(0);
        React.useEffect(() => {
            const refresh = () => render(value => value + 1);
            listeners.add(refresh);
            return () => listeners.delete(refresh);
        }, []);
        const intersection = props.intersection;
        const phase = props.phase;
        const plan = controller.getPlan(intersection.id);
        const custom = phase && plan?.customPhaseIds?.includes(phase.id);
        const mapping = custom ? plan.connections[phase.id] : (plan?.baseConnections || connectionsOf(intersection));
        const locked = controller.isEnabled() && !phase && Boolean(plan?.customPhaseIds?.length);
        const display = phase || locked ? withConnections(intersection, mapping) : intersection;
        function greenClick(laneId, phaseId) {
            const index = intersection.phaseIds.indexOf(phaseId);
            props.onLaneClick?.(laneId, phaseId);
            controller.migratePhase(intersection.id, phaseId, index);
            render(value => value + 1);
        }
        function stopLocked(event) {
            if (locked) { event.preventDefault(); event.stopPropagation(); }
        }
        const children = [jsx.jsx('div', {
            className: 'manipulation-native-title',
            children: 'Traffic light #' + intersection.id + (phase ? ' · Phase ' + (intersection.phaseIds.indexOf(phase.id) + 1) : '')
        }, 'identity'), jsx.jsx('div', {
            style: locked ? { opacity: 0.4 } : undefined,
            onPointerDownCapture: stopLocked,
            onClickCapture: stopLocked,
            onContextMenuCapture: stopLocked,
            onMouseDownCapture: stopLocked,
            children: jsx.jsx(NativeDiagram, { ...props, intersection: display, onLaneClick: greenClick })
        }, 'diagram')];
        if (controller.isEnabled() && (phase || locked)) children.push(jsx.jsx('small', {
            children: phase ? 'Use the normal red/green controls. Edit individual connections in the mod menu only (Alt+M).' : 'The general diagram is locked. Edit or reset individual connections in the mod menu (Alt+M).'
        }, 'help'));
        if (controller.status) children.push(jsx.jsx('small', {role: 'status', children: controller.status}, 'status'));
        return jsx.jsx('div', { className: 'manipulation-native-signals', children });
    }
    class SignalErrorBoundary extends React.Component {
        constructor(props) { super(props); this.state = { failed: false }; }
        static getDerivedStateFromError() { return { failed: true }; }
        componentDidCatch(error) {
            controller.status = 'Traffic light extension: ' + error.message;
            console.error('[maipulation-mod] Traffic light editor:', error);
        }
        render() { return this.state.failed ? jsx.jsx(NativeDiagram, this.props.diagramProps) : this.props.children; }
    }
    function ProtectedSignalDiagram(props) {
        return jsx.jsx(SignalErrorBoundary, { diagramProps: props, children: jsx.jsx(NativeSignalDiagram, props) });
    }
    Object.defineProperty(diagrams, 'IntersectionSVG', { configurable: true, enumerable: true, value: ProtectedSignalDiagram });
}
