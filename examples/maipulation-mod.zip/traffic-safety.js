export function safetyEnabled() {
    return globalThis.__manipulationControl?Atomics.load(globalThis.__manipulationControl,1)===1:globalThis.__intelligentTraffic===true;
}

export function trafficSpatialIndex(cars,time) {
    const key=cars.exists?.buffer||cars,maximum=cars.getMaxResidentId(),cache=globalThis.__trafficSpatial;
    if(cache?.key===key&&cache.time===time&&cache.maximum===maximum)return cache;
    const cells=new Map(),size=128;
    for(let id=1;id<=maximum;id++){
        if(!cars.getExists(id)||cars.getParkedInGarageBuildingId(id)!=null||cars.getParkedInParkingSpaceLocator(id)!=null)continue;
        const x=cars.getCarX(id),y=cars.getCarY(id);if(!Number.isFinite(x+y))continue;
        const cell=Math.floor(x/size)+','+Math.floor(y/size);
        if(!cells.has(cell))cells.set(cell,[]);cells.get(cell).push(id);
    }
    return globalThis.__trafficSpatial={key,time,maximum,cells,size};
}

export function trafficNearby(cars,time,x,y) {
    const index=trafficSpatialIndex(cars,time),cx=Math.floor(x/index.size),cy=Math.floor(y/index.size),result=[];
    for(let dx=-2;dx<=2;dx++)for(let dy=-2;dy<=2;dy++)for(const id of index.cells.get((cx+dx)+','+(cy+dy))||[])result.push(id);
    return result;
}

export function trafficChangeRequired(car,network) {
    const p=car.path?.get(0),id=p?.equivalentLanePointLaneSectionId,index=p?.equivalentLanePointPointIndex;
    if(id==null||index==null)return true;
    if(car.__roadMergeAttempt?.key?.startsWith('merge-'))return true;
    if(Number.isFinite(globalThis.__roadLaneHorizon?.(car,network.laneSections,id,index,0)))return true;
    const dest=car.route?.[0]?.edgeToGetHere?.destinationLanePointLocator;
    let laneId=id;
    for(let step=0;laneId!=null&&step<64;step++){
        const lane=network.laneSections[laneId];if(!lane)return true;
        const part=car.allowedLaneSubsections?.find(s=>s.laneSectionId===laneId&&s.firstAllowedPointIndex<=(laneId===id?index:0));
        if(!part)return true;
        if(dest?.laneSectionId===laneId&&part.lastAllowedPointIndex>=dest.pointIndex)return false;
        if(part.lastAllowedPointIndex<lane.points.length-1)return true;
        if(lane.continuesTo==null)return false;laneId=lane.continuesTo;
    }
    return true;
}

export function deferTrafficMerge(car,network,cars,time) {
    car.__trafficNextMergeCheck=time+.35+(car.residentId%7)*.035;
    if(!trafficChangeRequired(car,network)){
        car.laneChangeIntent=0;car.laneSwitchPressure=0;
        cars.setIndicationMode?.(car.residentId,'none');
        car.__trafficStayUntil=time+1;
    }
    const stats=globalThis.__trafficStats??={};stats.unsafeMergesDeferred=(stats.unsafeMergesDeferred||0)+1;
    return false;
}

export function releaseTrafficMerge(car) {
    const slots=globalThis.__trafficMergeReservations;
    if(slots&&car?.residentId>=0&&1+car.residentId*6+5<slots.length)Atomics.store(slots,1+car.residentId*6,0);
    if(car){car.__trafficMergeClaim=false;car.__trafficMergeAccepted=false;}
}

export function trafficMergeGap(manager,car,from,to,time,reserve=true,force=false) {
    if(!safetyEnabled()&&!force&&!(globalThis.__roadToolsEnabled?.()&&car.__roadMergeAttempt))return true;
    if(!from||!to)return false;
    if(reserve&&time<(car.__trafficNextMergeCheck||0))return false;
    const cars=manager.carMetadata,point=manager.roadNetwork.laneSections[to.laneSectionId]?.points.pointOrUndefined(to.pointIndex);
    if(!point)return false;
    const id=car.residentId,x=cars.getCarX(id),y=cars.getCarY(id),speed=Math.max(0,cars.getSpeed(id));
    const headwaySpeed=Math.max(speed,cars.getMaxSpeed(id)*.3,8),duration=Math.max(.35,Math.min(1.4,Math.hypot(point.x-x,point.y-y)/headwaySpeed));
    const ca=Math.cos(point.a),sa=Math.sin(point.a),elevation=point.elevation??0;
    const slots=globalThis.__trafficMergeReservations,now=Math.floor(time*100);
    // Never wait while another worker owns the reservation lock. Retrying on
    // the next frame lets every worker finish its current simulation step.
    if(reserve&&slots&&Atomics.compareExchange(slots,0,0,id+1)!==0)return false;
    try{
        for(const other of trafficNearby(cars,time,point.x,point.y)){
            if(other===id||!cars.getExists(other))continue;
            if(slots){
                const at=1+other*6;
                if(at+5<slots.length&&Atomics.load(slots,at)!==0&&Atomics.load(slots,at+5)>now){
                    const dx=Atomics.load(slots,at+2)/100-point.x,dy=Atomics.load(slots,at+3)/100-point.y;
                    const dz=Atomics.load(slots,at+4)/100-elevation;
                    const swap=Atomics.load(slots,at)===from.laneSectionId&&Atomics.load(slots,at+1)===to.laneSectionId;
                    if(Math.abs(dz)<.25&&Math.abs(dx*ca+dy*sa)<35&&(Math.abs(-dx*sa+dy*ca)<12||swap))return reserve?deferTrafficMerge(car,manager.roadNetwork,cars,time):false;
                }
            }
            if(Math.abs((cars.getElevation(other)||0)-elevation)>.25)continue;
            const ox=cars.getCarX(other),oy=cars.getCarY(other),a=cars.getCarA(other),v=Math.max(0,cars.getSpeed(other));
            const vx=Math.cos(a)*v,vy=Math.sin(a)*v,forward=vx*ca+vy*sa;
            let tail=0;
            if(cars.getTrailerX&&cars.getTrailerY){const distance=Math.hypot(ox-cars.getTrailerX(other),oy-cars.getTrailerY(other));if(distance>5&&distance<50)tail=Math.min(30,distance);}
            const padding=18+(car.vehicleType==='truck'?15:0)+tail*.5;
            const front=padding+speed*.25,rear=padding+Math.max(0,forward-speed)*.7+Math.max(0,forward)*.2;
            for(const t of [0,duration*.5,duration]){
                const dx=ox+vx*t-point.x,dy=oy+vy*t-point.y;
                const along=dx*ca+dy*sa,lateral=-dx*sa+dy*ca;
                if(Math.abs(lateral)<12&&along>=-rear&&along<=front)return reserve?deferTrafficMerge(car,manager.roadNetwork,cars,time):false;
            }
        }
        if(!reserve)return true;
        if(slots){
            const at=1+id*6;if(at+5>=slots.length)return false;
            Atomics.store(slots,at+1,from.laneSectionId);Atomics.store(slots,at+2,Math.round(point.x*100));Atomics.store(slots,at+3,Math.round(point.y*100));Atomics.store(slots,at+4,Math.round(elevation*100));Atomics.store(slots,at+5,now+200);Atomics.store(slots,at,to.laneSectionId);
        }
        car.__trafficMergeClaim=true;car.__trafficMergeAccepted=false;
        return true;
    }finally{if(reserve&&slots)Atomics.store(slots,0,0);}
}

export function trafficPathClear(manager,car,path,time) {
    if(!safetyEnabled()&&!(globalThis.__roadToolsEnabled?.()&&car.__roadMergeAttempt))return true;
    const length=path.length();
    for(let i=0;i<length;i+=2){
        const p=path.get(i);
        if(!manager.canAcquireHardLockAtPose(p.x,p.y,p.a,p.elevation??0,car.residentId))return deferTrafficMerge(car,manager.roadNetwork,manager.carMetadata,time);
    }
    if(length){const p=path.get(length-1);if(!manager.canAcquireHardLockAtPose(p.x,p.y,p.a,p.elevation??0,car.residentId))return deferTrafficMerge(car,manager.roadNetwork,manager.carMetadata,time);}
    return true;
}

export function trafficPreferAllowed(car,lanes,laneId,index,offset) {
    const network={laneSections:lanes};
    if(trafficChangeRequired(car,network))return false;
    const cars=globalThis.__trafficCars;if(!cars)return true;
    const target=offset<0?lanes[laneId]?.leftGluedLaneSectionId:lanes[laneId]?.rightGluedLaneSectionId;
    if(target==null||index+15>=lanes[target].points.length)return false;
    const time=globalThis.__trafficClock?.[0]||0;
    if(trafficMergeGap({roadNetwork:network,carMetadata:cars},car,{laneSectionId:laneId,pointIndex:index},{laneSectionId:target,pointIndex:index+15},time,false,true))return true;
    return deferTrafficMerge(car,network,cars,time);
}

export function trafficBlockedOptional(manager,car,time) {
    if((safetyEnabled()||car.__roadMergeAttempt?.key?.startsWith('prefer-'))&&!trafficChangeRequired(car,manager.roadNetwork)){
        deferTrafficMerge(car,manager.roadNetwork,manager.carMetadata,time);return true;
    }
    return false;
}

export function trafficMergeFinish(car) {
    if(car?.__trafficMergeClaim&&!car.__trafficMergeAccepted)releaseTrafficMerge(car);
    if(car)car.__trafficMergeClaim=false;
}

export function trafficSafetyTick(car,cars,time) {
    const slots=globalThis.__trafficMergeReservations;if(!slots||!car)return;
    const at=1+car.residentId*6;if(at+5>=slots.length||Atomics.load(slots,at)===0)return;
    if(car.cleanswitchLockId!=null||car.path?.get(0)?.switchingLaneFromLaneSectionId!=null)Atomics.store(slots,at+5,Math.floor(time*100)+200);
    else releaseTrafficMerge(car);
}

export function installTrafficSafetySource(source) {
    const functions=[safetyEnabled,trafficSpatialIndex,trafficNearby,trafficChangeRequired,deferTrafficMerge,releaseTrafficMerge,trafficMergeGap,trafficPathClear,trafficMergeFinish,trafficSafetyTick,trafficPreferAllowed,trafficBlockedOptional];
    return '(function(){'+functions.map(fn=>fn.toString()).join('\n')+';Object.assign(globalThis,{__trafficPreferAllowed:trafficPreferAllowed,__trafficBlockedOptional:trafficBlockedOptional,__trafficMergeGap:trafficMergeGap,__trafficPathClear:trafficPathClear,__trafficMergeFinish:trafficMergeFinish,__trafficSafetyTick:trafficSafetyTick,__trafficChangeRequired:trafficChangeRequired,__releaseTrafficMerge:releaseTrafficMerge});self.addEventListener("message",event=>{if(event.data?.__trafficMergeBuffer)globalThis.__trafficMergeReservations=new Int32Array(event.data.__trafficMergeBuffer);},true);})();\n'+source;
}
